@extends('layouts.app')
@section('page-title')
    {{ __('Dashboard') }}
@endsection
@section('breadcrumb')
    <ul class="breadcrumb mb-0">
        <li class="breadcrumb-item">
            <a href="{{ route('dashboard') }}">{{ __('Dashboard') }}</a>
        </li>

    </ul>
@endsection

@section('content')
    <div class="row">
        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-primary bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-list f-20 text-primary"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase">{{ __('Total Request') }}</p>
                        <h5 class="mb-0">{{ $result['totalRequest'] ?? 0 }}</h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-success bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-calendar f-20 text-success"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase">{{ __('Today Request') }}</p>
                        <h5 class="mb-0">{{ $result['todayRequest'] ?? 0 }}</h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-info bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-tool f-20 text-info"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase">{{ __('Pending Request') }}</p>
                        <h5 class="mb-0">{{ $result['pendingRequest'] ?? 0 }}</h5>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="row mt-3">
        <div class="col-12">
            <div class="card border-0">
                <div class="card-body">
                    <p class="text-muted mb-3 fw-semibold text-uppercase">
                        <i class="ti ti-building f-20 me-2"></i>{{ __('Assigned Properties') }}
                    </p>
                    <div class="d-flex flex-wrap gap-2">
                        @foreach ($maintainer->properties() as $property)
                            <span
                                class="badge rounded-pill px-3 py-2 fs-6 fw-medium bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25">
                                <i class="ti ti-building me-1"></i>{{ $property->name }}
                            </span>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card table-card">
                <div class="card-header">
                    <h5>{{ __('Pending Request') }}</h5>
                </div>
                <div class="card body">
                    <div class="dt-responsive table-responsive">
                        <table class="table table-hover advance-datatable">
                            <thead>
                                <tr>
                                    <th>{{ __('Property') }}</th>
                                    <th>{{ __('Unit') }}</th>
                                    <th>{{ __('Tenant') }}</th>
                                    <th>{{ __('Issue') }}</th>
                                    <th>{{ __('Request Date') }}</th>

                                    @if (Gate::check('show maintenance request'))
                                        <th class="text-right">{{ __('Action') }}</th>
                                    @endif
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($result['pendingRequestList'] as $request)
                                    <tr role="row">
                                        <td> {{ !empty($request->properties) ? $request->properties->name : '-' }} </td>
                                        <td> {{ !empty($request->units) ? $request->units->name : '-' }} </td>
                                        <td>{{ !empty($request->tenetData->user) ? $request->tenetData->user->full_name : '-' }}
                                        </td>
                                        <td> {{ !empty($request->types) ? $request->types->title : '-' }} </td>
                                        <td> {{ dateFormat($request->request_date) }} </td>

                                        @if (Gate::check('show maintenance request'))
                                            <td class="text-right">
                                                <div class="cart-action">
                                                    {!! Form::open(['method' => 'DELETE', 'route' => ['maintenance-request.destroy', $request->id]]) !!}
                                                    @can('show maintenance request')
                                                        <a class="avtar avtar-xs btn-link-warning text-warning"
                                                            data-bs-toggle="tooltip"
                                                            data-bs-original-title="{{ __('Show') }}"
                                                            href="{{ route('maintenance-request.show', \Crypt::encrypt($request->id)) }}"
                                                            data-title="{{ __('Maintenance Request Details') }}"> <i
                                                                data-feather="eye"></i></a>
                                                    @endcan
                                                </div>

                                            </td>
                                        @endif
                                    </tr>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card table-card">
                <div class="card-header">
                    <h5>{{ __('Today Request') }}</h5>
                </div>
                <div class="card body">
                    <div class="dt-responsive table-responsive">
                        <table class="table table-hover advance-datatable">
                            <thead>
                                <tr>
                                    <th>{{ __('Property') }}</th>
                                    <th>{{ __('Unit') }}</th>
                                    <th>{{ __('Tenant') }}</th>
                                    <th>{{ __('Issue') }}</th>
                                    <th>{{ __('Request Date') }}</th>

                                    @if (Gate::check('show maintenance request'))
                                        <th class="text-right">{{ __('Action') }}</th>
                                    @endif
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($result['todayRequestList'] as $request)
                                    <tr role="row">
                                        <td> {{ !empty($request->properties) ? $request->properties->name : '-' }} </td>
                                        <td> {{ !empty($request->units) ? $request->units->name : '-' }} </td>
                                        <td>{{ !empty($request->tenetData->user) ? $request->tenetData->user->full_name : '-' }}</td>
                                        <td> {{ !empty($request->types) ? $request->types->title : '-' }} </td>
                                        <td> {{ dateFormat($request->request_date) }} </td>

                                        @if (Gate::check('show maintenance request'))
                                            <td class="text-right">
                                                <div class="cart-action">
                                                    {!! Form::open(['method' => 'DELETE', 'route' => ['maintenance-request.destroy', $request->id]]) !!}
                                                    @can('show maintenance request')
                                                        <a class="avtar avtar-xs btn-link-warning text-warning"
                                                            data-bs-toggle="tooltip"
                                                            data-bs-original-title="{{ __('Show') }}"
                                                            href="{{ route('maintenance-request.show', \Crypt::encrypt($request->id)) }}"
                                                            data-title="{{ __('Maintenance Request Details') }}"> <i
                                                                data-feather="eye"></i></a>
                                                    @endcan
                                                </div>
                                            </td>
                                        @endif
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
