<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Income Report')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Income Report')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card table-card">
                <div class="card-header">
                    <div class="row align-items-center g-2 flex-wrap">
                        <div class="col-12 col-md-4">
                            <h5 class="mb-0"><?php echo e(__('Income Report')); ?></h5>
                        </div>
                        <div class="col-12 col-md-8">
                            <div class="d-flex flex-wrap gap-3 align-items-end">

                                <div class="col">
                                    <?php echo e(Form::label('property_id', __('Property'), ['class' => 'form-label'])); ?>

                                    <?php echo e(Form::select('property_id', $property, request('property_id'), [
                                        'class' => 'form-control select2 property',
                                        'id' => 'property_id',
                                    ])); ?>

                                </div>

                                <div class="col">
                                    <?php echo e(Form::label('unit_id', __('Unit'), ['class' => 'form-label'])); ?>

                                    <div class="unit_div">
                                        <select class="form-control select2 unit" id="unit_id" name="unit_id">
                                            <option value=""><?php echo e(__('Select Unit')); ?></option>
                                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($id); ?>"
                                                    <?php echo e(request('unit_id') == $id ? 'selected' : ''); ?>>
                                                    <?php echo e($name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col">
                                    <?php echo e(Form::label('month', __('Month'), ['class' => 'form-label'])); ?>

                                    <?php echo e(Form::month('month', request('month'), [
                                        'class' => 'form-control month',
                                        'placeholder' => __('Select month'),
                                    ])); ?>

                                </div>
                                <div class="col">
                                    <b><?php echo e(Form::label('date range', __('Date'), ['class' => 'form-label'])); ?></b>
                                    <?php echo e(Form::text('date', request('date'), [
                                        'class' => 'form-control  date',
                                        'placeholder' => __('Select date range'),
                                        'id' => 'demo',
                                        'autocomplete' => 'off',
                                    ])); ?>

                                </div>

                                <div class="col-auto d-flex gap-2">
                                    <button type="button" class="btn btn-secondary subbtn">
                                        <i class="ti ti-search"></i>
                                    </button>
                                    <button type="button" class="btn btn-primary" onclick="window.location.reload();">
                                        <i class="ti ti-refresh"></i>
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

                <div class="card-body pt-0" id="invoice-report">

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script-page'); ?>
    <script>
        $('#demo').daterangepicker({
            autoApply: true,
            autoUpdateInput: false,
            locale: {
                format: 'MM/DD/YYYY'
            }
        }, function(start, end) {
            $('#demo').val(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        });

        $(function() {
            $('#property_id').on('change', function() {
                let property_id = $(this).val();

                if (!property_id) {
                    resetUnitDropdown();
                    return;
                }

                let url = '<?php echo e(route('property.unit', ':id')); ?>'.replace(':id', property_id);

                $.ajax({
                    url: url,
                    type: 'GET',
                    success: function(data) {
                        let options = `<option value="">Select Unit</option>`;

                        $.each(data, function(key, value) {
                            options += `<option value="${key}">${value}</option>`;
                        });

                        $('#unit_id').html(options).trigger('change');
                    },
                    error: function() {
                        resetUnitDropdown();
                    }
                });
            });

            $('.subbtn').on('click', function() {
                loadReport();
            });

            function loadReport() {

                let data = {
                    property_id: $('#property_id').val(),
                    unit_id: $('#unit_id').val(),
                    month: $('.month').val(),
                    date: $('#demo').val(),
                };

                $.ajax({
                    url: '<?php echo e(route('report.income')); ?>',
                    method: 'GET',
                    data: data,
                    success: function(response) {
                        $('#invoice-report').html(response.html);
                        if (typeof datatable === 'function') {
                            datatable();
                        }
                    },
                    error: function(xhr) {
                        let msg = 'Error loading report';
                        if (xhr.responseJSON?.message) {
                            msg = xhr.responseJSON.message;
                        }
                        console.error(msg);
                    }
                });
            }

            function resetUnitDropdown() {
                $('#unit_id').html(`<option value="">Select Unit</option>`).trigger('change');
            }

            loadReport();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/report/income.blade.php ENDPATH**/ ?>