<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Poll')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('poll.index')); ?>"><?php echo e(__('Polls')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Results')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header"><h5 class="mb-0"><?php echo e($poll->question); ?></h5>
                    <small class="text-muted"><?php echo e(array_sum($results->toArray())); ?> <?php echo e(__('votes')); ?> &middot; <?php echo e($poll->isOpen() ? __('Open') : __('Closed')); ?></small></div>
                <div class="card-body">
                    <?php if($poll->description): ?><p><?php echo nl2br(e($poll->description)); ?></p><?php endif; ?>
                    <?php echo $__env->make('poll._results', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/poll/show.blade.php ENDPATH**/ ?>