<div class="dt-responsive table-responsive">
    <table class="table table-hover advance-datatable">
        <thead>
            <tr>
                <th><?php echo e(__('Property')); ?></th>
                <th><?php echo e(__('Name')); ?></th>
                <th><?php echo e(__('Tenant')); ?></th>
                <th><?php echo e(__('Rent Type')); ?></th>
                <th><?php echo e(__('Rent')); ?></th>
                <th><?php echo e(__('Rent Duration')); ?></th>
                <th><?php echo e(__('Status')); ?></th>
                <?php if(Gate::check('edit unit') || Gate::check('delete unit')): ?>
                    <th class="text-right"><?php echo e(__('Action')); ?></th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(!empty($unit->properties) ? $unit->properties->name : '-'); ?> </td>
                    <td><?php echo e(ucfirst($unit->name)); ?> </td>
                    <?php
                        $tenant = $unit->tenants();
                    ?>

                    <?php if(empty($tenant) || !empty($tenant->exit_date)): ?>
                        <td><?php echo e('-'); ?></td>
                    <?php else: ?>
                        <td><?php echo e(!empty($tenant->user) ? $tenant->user->name : '-'); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($unit->rent_type); ?> </td>
                    <td><?php echo e(priceFormat($unit->rent)); ?> </td>
                    <td>
                        <?php if($unit->rent_type == 'custom'): ?>
                            <span><?php echo e(__('Start Date')); ?> :- </span><?php echo e(dateFormat($unit->start_date)); ?>

                            <br>
                            <span><?php echo e(__('End Date')); ?> :- </span><?php echo e(dateFormat($unit->end_date)); ?>

                            <br>
                            <span><?php echo e(__('Payment Due Date')); ?> :-
                            </span><?php echo e(dateFormat($unit->payment_due_date)); ?>

                        <?php else: ?>
                            <?php echo e($unit->rent_duration); ?>

                        <?php endif; ?>
                    </td>
                    </td>
                    <?php if($unit->is_occupied == 1): ?>
                        <td class="text-danger">
                            <i class="fas fa-circle f-10 m-r-10"></i>
                            <?php echo e(__('Occupied')); ?>

                        </td>
                    <?php else: ?>
                        <td class="text-success">
                            <i class="fas fa-circle f-10 m-r-10"></i>
                            <?php echo e(__('Vacant')); ?>

                        </td>
                    <?php endif; ?>

                    <?php if(Gate::check('edit unit') || Gate::check('delete unit')): ?>
                        <td class="text-right">
                            <div class="cart-action">
                                <?php echo Form::open(['method' => 'DELETE', 'route' => ['unit.destroy', [$unit->property_id, $unit->id]]]); ?>


                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show unit')): ?>
                                    <a class="avtar avtar-xs btn-link-warning text-warning"
                                        href="<?php echo e(route('unit.show', \Crypt::encrypt($unit->id))); ?>"
                                        data-bs-toggle="tooltip" data-bs-original-title="<?php echo e(__('Show')); ?>">
                                        <i data-feather="eye"></i></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit unit')): ?>
                                    <a class="avtar avtar-xs btn-link-secondary text-secondary customModal"
                                        data-url="<?php echo e(route('unit.edit', [$unit->property_id, $unit->id])); ?>" href="#"
                                        data-size="lg" data-title="<?php echo e(__('Edit Unit')); ?>" data-bs-toggle="tooltip"
                                        data-bs-original-title="<?php echo e(__('Edit')); ?>">
                                        <i data-feather="edit"></i></a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete unit')): ?>
                                    <a class="avtar avtar-xs btn-link-danger text-danger confirm_dialog"
                                        data-bs-toggle="tooltip" data-bs-original-title="<?php echo e(__('Detete')); ?>"
                                        href="#"> <i data-feather="trash-2"></i></a>
                                <?php endif; ?>
                                <?php echo Form::close(); ?>

                            </div>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
</div>
<?php /**PATH /home/etheonbe/public_html/resources/views/unit/unit_list.blade.php ENDPATH**/ ?>