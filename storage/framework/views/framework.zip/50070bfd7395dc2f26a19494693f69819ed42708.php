<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Dashboard')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="breadcrumb mb-0">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
        </li>

    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-primary bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-list f-20 text-primary"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Total Request')); ?></p>
                        <h5 class="mb-0"><?php echo e($result['totalRequest'] ?? 0); ?></h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-success bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-calendar f-20 text-success"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Today Request')); ?></p>
                        <h5 class="mb-0"><?php echo e($result['todayRequest'] ?? 0); ?></h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-info bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-tool f-20 text-info"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Pending Request')); ?></p>
                        <h5 class="mb-0"><?php echo e($result['pendingRequest'] ?? 0); ?></h5>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="row mt-3">
        <div class="col-12">
            <div class="card border-0">
                <div class="card-body">
                    <p class="text-muted mb-3 fw-semibold text-uppercase">
                        <i class="ti ti-building f-20 me-2"></i><?php echo e(__('Assigned Properties')); ?>

                    </p>
                    <div class="d-flex flex-wrap gap-2">
                        <?php $__currentLoopData = $maintainer->properties(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="badge rounded-pill px-3 py-2 fs-6 fw-medium bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25">
                                <i class="ti ti-building me-1"></i><?php echo e($property->name); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card table-card">
                <div class="card-header">
                    <h5><?php echo e(__('Pending Request')); ?></h5>
                </div>
                <div class="card body">
                    <div class="dt-responsive table-responsive">
                        <table class="table table-hover advance-datatable">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Property')); ?></th>
                                    <th><?php echo e(__('Unit')); ?></th>
                                    <th><?php echo e(__('Tenant')); ?></th>
                                    <th><?php echo e(__('Issue')); ?></th>
                                    <th><?php echo e(__('Request Date')); ?></th>

                                    <?php if(Gate::check('show maintenance request')): ?>
                                        <th class="text-right"><?php echo e(__('Action')); ?></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $result['pendingRequestList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr role="row">
                                        <td> <?php echo e(!empty($request->properties) ? $request->properties->name : '-'); ?> </td>
                                        <td> <?php echo e(!empty($request->units) ? $request->units->name : '-'); ?> </td>
                                        <td><?php echo e(!empty($request->tenetData->user) ? $request->tenetData->user->full_name : '-'); ?>

                                        </td>
                                        <td> <?php echo e(!empty($request->types) ? $request->types->title : '-'); ?> </td>
                                        <td> <?php echo e(dateFormat($request->request_date)); ?> </td>

                                        <?php if(Gate::check('show maintenance request')): ?>
                                            <td class="text-right">
                                                <div class="cart-action">
                                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['maintenance-request.destroy', $request->id]]); ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show maintenance request')): ?>
                                                        <a class="avtar avtar-xs btn-link-warning text-warning"
                                                            data-bs-toggle="tooltip"
                                                            data-bs-original-title="<?php echo e(__('Show')); ?>"
                                                            href="<?php echo e(route('maintenance-request.show', \Crypt::encrypt($request->id))); ?>"
                                                            data-title="<?php echo e(__('Maintenance Request Details')); ?>"> <i
                                                                data-feather="eye"></i></a>
                                                    <?php endif; ?>
                                                </div>

                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card table-card">
                <div class="card-header">
                    <h5><?php echo e(__('Today Request')); ?></h5>
                </div>
                <div class="card body">
                    <div class="dt-responsive table-responsive">
                        <table class="table table-hover advance-datatable">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Property')); ?></th>
                                    <th><?php echo e(__('Unit')); ?></th>
                                    <th><?php echo e(__('Tenant')); ?></th>
                                    <th><?php echo e(__('Issue')); ?></th>
                                    <th><?php echo e(__('Request Date')); ?></th>

                                    <?php if(Gate::check('show maintenance request')): ?>
                                        <th class="text-right"><?php echo e(__('Action')); ?></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $result['todayRequestList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr role="row">
                                        <td> <?php echo e(!empty($request->properties) ? $request->properties->name : '-'); ?> </td>
                                        <td> <?php echo e(!empty($request->units) ? $request->units->name : '-'); ?> </td>
                                        <td><?php echo e(!empty($request->tenetData->user) ? $request->tenetData->user->full_name : '-'); ?></td>
                                        <td> <?php echo e(!empty($request->types) ? $request->types->title : '-'); ?> </td>
                                        <td> <?php echo e(dateFormat($request->request_date)); ?> </td>

                                        <?php if(Gate::check('show maintenance request')): ?>
                                            <td class="text-right">
                                                <div class="cart-action">
                                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['maintenance-request.destroy', $request->id]]); ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show maintenance request')): ?>
                                                        <a class="avtar avtar-xs btn-link-warning text-warning"
                                                            data-bs-toggle="tooltip"
                                                            data-bs-original-title="<?php echo e(__('Show')); ?>"
                                                            href="<?php echo e(route('maintenance-request.show', \Crypt::encrypt($request->id))); ?>"
                                                            data-title="<?php echo e(__('Maintenance Request Details')); ?>"> <i
                                                                data-feather="eye"></i></a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/dashboard/maintainer.blade.php ENDPATH**/ ?>