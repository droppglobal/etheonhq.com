<?php if(!empty($c['items'])): ?>
    <section class="our-features" id="<?php echo e($sectionId); ?>">
        <div class="container wow fadeInUp">
            <div class="row">
                <div class="col-lg-12">
                    <div class="main-title text-center">
                        <h2><?php echo e($c['Sec1_title'] ?? ''); ?></h2>
                        <p class="text"><?php echo e($c['Sec1_info'] ?? ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $c['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-lg-3 mb-4">
                        <div class="iconbox-style1 border-less p-0">
                            <?php if(!empty($item['image_path'])): ?>
                                <div class="icon before-none">
                                    <img src="<?php echo e(\App\Support\WebsiteImage::url($item['image_path'], 640)); ?>" alt="<?php echo e($item['title'] ?? ''); ?>" class="activity-img" loading="lazy" />
                                </div>
                            <?php endif; ?>
                            <div class="details">
                                <h4 class="title mt10 mb-3"><?php echo e($item['title'] ?? ''); ?></h4>
                                <p class="text"><?php echo e($item['info'] ?? ''); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/sections/highlights.blade.php ENDPATH**/ ?>