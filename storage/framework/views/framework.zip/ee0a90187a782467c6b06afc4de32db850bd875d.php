<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Dashboard')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <ul class="breadcrumb mb-0">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-primary bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-building f-20 text-primary"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Property')); ?></p>
                        <h5 class="mb-0">
                            <?php echo e(!empty($tenant->properties) ? $tenant->properties->name : '-'); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-success bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-layout-grid f-20 text-success"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Unit')); ?></p>
                        <h5 class="mb-0">
                            <?php echo e(!empty($tenant->units) ? $tenant->units->name : '-'); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-warning bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-cash f-20 text-warning"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Rent')); ?></p>
                        <h5 class="mb-0">
                            <?php echo e(getSettingsValByName('CURRENCY_SYMBOL')); ?><?php echo e(!empty($result['unit']) ? $result['unit']->rent : '-'); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-danger bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-credit-card f-20 text-danger"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Pending Payment')); ?></p>
                        <h5 class="mb-0">
                            <?php echo e(getSettingsValByName('CURRENCY_SYMBOL')); ?><?php echo e($result['totalPendingPayment'] ?? 0); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-info bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-tool f-20 text-info"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Pending Request')); ?></p>
                        <h5 class="mb-0">
                            <?php echo e($result['pendingMaintenance'] ?? 0); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-4 col-sm-6">
            <div class="card border-0">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="rounded-3 p-3 bg-secondary bg-opacity-10 flex-shrink-0">
                        <i class="ti ti-calendar f-20 text-secondary"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 fs-5 fw-semibold text-uppercase"><?php echo e(__('Agreement Date')); ?></p>
                        <h5 class="mb-0">
                            <?php echo e(!empty($result['agreement'])
                                ? dateFormat($result['agreement']->agreement_start_date) .
                                    ' - ' .
                                    dateFormat($result['agreement']->agreement_end_date)
                                : '-'); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5><?php echo e(__('Due / Overdue Invoices')); ?></h5>
                </div>
                <div class="card-body pt-0">

                    <div class="dt-responsive table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Invoice')); ?></th>
                                    <th><?php echo e(__('Property & Unit')); ?></th>
                                    <th><?php echo e(__('Invoice Month')); ?></th>
                                    <th><?php echo e(__('End Date')); ?></th>
                                    <th><?php echo e(__('Amount')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $result['overdueInvoices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show invoice')): ?>
                                                <a href="<?php echo e(route('invoice.show', \Crypt::encrypt($invoice->id))); ?>"
                                                    data-bs-toggle="tooltip" data-bs-original-title="<?php echo e(__('View')); ?>">
                                                    <?php echo e(invoicePrefix() . $invoice->invoice_id); ?>

                                                </a>
                                            <?php else: ?>
                                                <?php echo e(invoicePrefix() . $invoice->invoice_id); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="fw-semibold">
                                                <?php echo e(optional($invoice->properties)->name); ?>

                                            </div>
                                            <div class="text-muted fs-5">
                                                <?php echo e(optional($invoice->units)->name); ?>

                                            </div>
                                        </td>
                                        <td><?php echo e(date('F Y', strtotime($invoice->invoice_month))); ?> </td>
                                        <td><?php echo e(dateFormat($invoice->end_date)); ?> </td>
                                        <td><?php echo e(priceFormat($invoice->getInvoiceSubTotalAmount())); ?></td>
                                        <td>
                                            <?php if($invoice->status == 'unpaid'): ?>
                                                <span
                                                    class="badge bg-light-danger"><?php echo e(\App\Models\Invoice::status()[$invoice->status]); ?></span>
                                            <?php elseif($invoice->status == 'paid'): ?>
                                                <span
                                                    class="badge bg-light-success"><?php echo e(\App\Models\Invoice::status()[$invoice->status]); ?></span>
                                            <?php elseif($invoice->status == 'partial_paid'): ?>
                                                <span
                                                    class="badge bg-light-warning"><?php echo e(\App\Models\Invoice::status()[$invoice->status]); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php if(!empty($result['maintenanceList']) && $result['maintenanceList']->count() > 0): ?>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><?php echo e(__('My Maintenance Requests')); ?></h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Subject')); ?></th>
                                        <th><?php echo e(__('Date')); ?></th>
                                        <th><?php echo e(__('Status')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $result['maintenanceList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(!empty($maintenance->types) ? $maintenance->types->title : '-'); ?></td>
                                            <td><?php echo e(dateFormat($maintenance->request_date)); ?></td>
                                            <td>
                                                <?php if($maintenance->status == 'pending'): ?>
                                                    <span class="badge bg-warning text-dark"><?php echo e(__('Pending')); ?></span>
                                                <?php elseif($maintenance->status == 'in_progress'): ?>
                                                    <span class="badge bg-info"><?php echo e(__('In Progress')); ?></span>
                                                <?php else: ?>
                                                    <span class="badge bg-success"><?php echo e(__('Completed')); ?></span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/dashboard/tenant.blade.php ENDPATH**/ ?>