
<?php
    $facts = \App\Support\PropertySearch::facts($property, \App\Support\WebsiteSite::for($user)->featuredIds());
    $images = $facts['images'] ?: ['upload/property/thumbnail/default.jpg'];
    $link = \App\Support\WebsiteSite::propertyUrl($user, $property);
    $type = \App\Models\Property::types()[$property->type] ?? '';
    $place = trim(implode(', ', array_filter([$property->city, $property->state])));
?>
<div class="site-card h-100" data-address="<?php echo e(trim(implode(', ', array_filter([$property->address, $property->city, $property->state, $property->zip_code, $property->country])))); ?>" data-name="<?php echo e($property->name); ?>">
    <div class="site-card-img position-relative">
        <div class="site-slider" data-slider>
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($link); ?>" class="site-slide" tabindex="<?php echo e($i ? -1 : 0); ?>">
                    <img src="<?php echo e(\App\Support\WebsiteImage::url($img, 640)); ?>" decoding="async" alt="<?php echo e($property->name); ?><?php echo e($i ? ' – ' . __('photo') . ' ' . ($i + 1) : ''); ?>" loading="lazy">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(count($images) > 1): ?>
            <button type="button" class="site-slider-btn prev" data-slide="-1" aria-label="<?php echo e(__('Previous photo')); ?>"><i class="fas fa-chevron-left"></i></button>
            <button type="button" class="site-slider-btn next" data-slide="1" aria-label="<?php echo e(__('Next photo')); ?>"><i class="fas fa-chevron-right"></i></button>
            <div class="site-slider-dots" aria-hidden="true">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="<?php echo e($i ? '' : 'active'); ?>"></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="site-tags">
            <span class="site-tag site-tag-<?php echo e($property->listing_type === 'sell' ? 'sale' : 'rent'); ?>"><?php echo e($property->listing_type === 'sell' ? __('For sale') : __('For rent')); ?></span>
            <?php $__currentLoopData = $facts['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="site-tag site-tag-<?php echo e($key); ?>"><?php echo e($label); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="button" class="site-fav-btn" data-fav="<?php echo e($property->id); ?>" aria-pressed="false" aria-label="<?php echo e(__('Save :property', ['property' => $property->name])); ?>"><i class="far fa-heart"></i><i class="fas fa-heart"></i></button>
        <?php if($property->price): ?>
            <span class="site-price-badge"><?php echo e(\App\Support\WebsiteSite::price($property->price)); ?></span>
        <?php endif; ?>
    </div>
    <div class="site-card-body">
        <?php if($type): ?><span class="site-card-type"><?php echo e($type); ?></span><?php endif; ?>
        <h5 class="mb-1"><a href="<?php echo e($link); ?>"><?php echo e(ucfirst($property->name)); ?></a></h5>
        <?php if($place): ?><p class="small text-muted mb-2"><i class="fas fa-map-marker-alt me-1"></i><?php echo e($place); ?></p><?php endif; ?>
        <?php if($facts['beds'] !== '' || $facts['baths'] !== '' || $facts['units']): ?>
            <ul class="site-facts">
                <?php if($facts['beds'] !== ''): ?><li title="<?php echo e(__('Bedrooms')); ?>"><i class="fas fa-bed"></i> <?php echo e($facts['beds']); ?> <span><?php echo e(__('Beds')); ?></span></li><?php endif; ?>
                <?php if($facts['baths'] !== ''): ?><li title="<?php echo e(__('Bathrooms')); ?>"><i class="fas fa-bath"></i> <?php echo e($facts['baths']); ?> <span><?php echo e(__('Baths')); ?></span></li><?php endif; ?>
                <?php if($facts['units']): ?><li title="<?php echo e(__('Units')); ?>"><i class="fas fa-door-open"></i> <?php echo e($facts['units']); ?> <span><?php echo e(__('Units')); ?></span></li><?php endif; ?>
            </ul>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center mt-2 gap-2">
            <?php if($property->listing_type !== 'sell' && $facts['vacant']): ?>
                <p class="site-card-avail m-0"><i class="fas fa-circle-check"></i> <?php echo e(__('Units available: :count', ['count' => $facts['vacant']])); ?></p>
            <?php else: ?>
                <span></span>
            <?php endif; ?>
            <label class="site-compare-check mb-0"><input type="checkbox" data-compare="<?php echo e($property->id); ?>"> <?php echo e(__('Compare')); ?></label>
        </div>
    </div>
</div>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/_property_card.blade.php ENDPATH**/ ?>