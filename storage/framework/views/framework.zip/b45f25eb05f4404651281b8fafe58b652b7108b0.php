<?php $site = \App\Support\WebsiteSite::for($user); ?>
<?php echo $__env->make('theme.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<body class="landing-page site-style-<?php echo e($site->design['layout_style'] ?? 'classic'); ?> site-buttons-<?php echo e($site->design['button_style'] ?? 'rounded'); ?> <?php echo e($site->rtl() ? 'site-rtl' : ''); ?>"
    data-pc-preset="<?php echo e(!empty($settings['color_type']) && $settings['color_type'] == 'custom' ? 'custom' : $settings['accent_color']); ?>"
    data-site="<?php echo e($user->code); ?>" data-saved-url="<?php echo e(route('web.saved', $user->code)); ?>" data-compare-url="<?php echo e(route('web.compare', $user->code)); ?>"
    data-label-compare="<?php echo e(__('Compare')); ?>" data-label-clear="<?php echo e(__('Clear')); ?>" data-label-max="<?php echo e(__('You can compare up to 3 properties.')); ?>"
    data-pc-sidebar-theme="light" data-pc-sidebar-caption="<?php echo e($settings['sidebar_caption']); ?>"
    data-pc-direction="<?php echo e($settings['theme_layout']); ?>" data-pc-theme="<?php echo e($settings['theme_mode']); ?>">

    <a href="#main-content" class="site-skip"><?php echo e(__('Skip to content')); ?></a>
    <div class="wrapper ovh">
        <div class="preloader"></div>


        <!-- Main Header Nav -->
        <?php echo $__env->make('theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="hiddenbar-body-ovelay"></div>

        <!-- Mobile Nav  -->
        <?php echo $__env->make('theme.mobile_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <div class="body_content" id="main-content" tabindex="-1">
            <?php echo $__env->yieldContent('content'); ?>

            <a class="scrollToHome" href="#"><i class="fas fa-angle-up"></i></a>
        </div>


    </div>
    <!-- Wrapper End -->


    <?php echo $__env->make('theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('theme.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="modal fade" id="customModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="body">
                </div>
            </div>
        </div>
    </div>


</body>

</html>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/main.blade.php ENDPATH**/ ?>