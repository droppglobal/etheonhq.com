<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Inspections')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Inspections')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card table-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo e(__('Inspections')); ?></h5>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create inspection')): ?>
                        <a href="#" class="btn btn-secondary customModal" data-size="md" data-url="<?php echo e(route('inspection.create')); ?>"
                            data-title="<?php echo e(__('New Inspection')); ?>"><i class="ti ti-circle-plus align-text-bottom"></i> <?php echo e(__('New Inspection')); ?></a>
                    <?php endif; ?>
                </div>
                <div class="card-body pt-0">
                    <div class="dt-responsive table-responsive">
                        <table class="table table-hover advance-datatable">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Date')); ?></th>
                                    <th><?php echo e(__('Type')); ?></th>
                                    <th><?php echo e(__('Tenant')); ?></th>
                                    <th><?php echo e(__('Property')); ?></th>
                                    <th><?php echo e(__('Issues')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th><?php echo e(__('Tenant Signed')); ?></th>
                                    <th class="text-right"><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $inspections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inspection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $issues = $inspection->items->whereIn('condition', ['poor', 'damaged'])->count(); ?>
                                    <tr>
                                        <td><?php echo e(dateFormat($inspection->inspection_date)); ?></td>
                                        <td><?php echo e(\App\Models\Inspection::types()[$inspection->type] ?? $inspection->type); ?></td>
                                        <td><?php echo e(optional(optional($inspection->tenants)->user)->name ?? '-'); ?></td>
                                        <td><?php echo e(optional($inspection->properties)->name); ?> / <?php echo e(optional($inspection->units)->name); ?></td>
                                        <td>
                                            <?php if($issues): ?>
                                                <span class="badge bg-light-danger"><?php echo e($issues); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">0</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="badge bg-light-<?php echo e($inspection->status == 'completed' ? 'success' : 'secondary'); ?>"><?php echo e($inspection->status == 'completed' ? __('Completed') : __('Draft')); ?></span></td>
                                        <td><?php echo e($inspection->tenant_signed_at ? dateFormat($inspection->tenant_signed_at) : '-'); ?></td>
                                        <td class="text-right">
                                            <div class="cart-action">
                                                <?php echo Form::open(['method' => 'DELETE', 'route' => ['inspection.destroy', $inspection->id]]); ?>

                                                <a class="avtar avtar-xs btn-link-warning text-warning" href="<?php echo e(route('inspection.show', $inspection->id)); ?>"><i data-feather="eye"></i></a>
                                                <?php if(\Auth::user()->type != 'tenant'): ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit inspection')): ?>
                                                        <?php if(empty($inspection->tenant_signed_at)): ?>
                                                            <a class="avtar avtar-xs btn-link-secondary text-secondary" href="<?php echo e(route('inspection.edit', $inspection->id)); ?>"><i data-feather="edit"></i></a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete inspection')): ?>
                                                        <a class="avtar avtar-xs btn-link-danger text-danger confirm_dialog" href="#"><i data-feather="trash-2"></i></a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php echo Form::close(); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/inspection/index.blade.php ENDPATH**/ ?>