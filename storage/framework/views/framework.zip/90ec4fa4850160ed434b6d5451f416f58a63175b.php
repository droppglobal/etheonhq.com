<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Facilities')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Facilities')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if($pending->count()): ?>
                <div class="card border-warning">
                    <div class="card-header"><h5 class="mb-0"><?php echo e(__('Waiting for approval')); ?> (<?php echo e($pending->count()); ?>)</h5></div>
                    <div class="card-body pt-0">
                        <table class="table mb-0">
                            <tbody>
                                <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="fw-semibold"><?php echo e(optional($booking->facility)->name); ?></td>
                                        <td><?php echo e(dateFormat($booking->booking_date)); ?> <?php echo e($booking->start_time); ?>-<?php echo e($booking->end_time); ?></td>
                                        <td><?php echo e(optional(optional($booking->tenants)->user)->name); ?> <small class="text-muted"><?php echo e(optional(optional($booking->tenants)->units)->name); ?></small></td>
                                        <td class="text-muted"><?php echo e($booking->notes); ?></td>
                                        <td class="text-end">
                                            <?php echo e(Form::open(['route' => ['facility.booking.decide', $booking->id], 'method' => 'post', 'class' => 'd-inline'])); ?>

                                            <button name="decision" value="approved" class="btn btn-sm btn-success"><?php echo e(__('Approve')); ?></button>
                                            <button name="decision" value="rejected" class="btn btn-sm btn-light-danger"><?php echo e(__('Reject')); ?></button>
                                            <?php echo e(Form::close()); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card table-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo e(__('Facilities')); ?></h5>
                    <a href="#" class="btn btn-secondary customModal" data-size="lg" data-url="<?php echo e(route('facility.create')); ?>" data-title="<?php echo e(__('Add Facility')); ?>">
                        <i class="ti ti-circle-plus align-text-bottom"></i> <?php echo e(__('Add Facility')); ?></a>
                </div>
                <div class="card-body pt-0">
                    <table class="table table-hover">
                        <thead><tr><th><?php echo e(__('Name')); ?></th><th><?php echo e(__('Property')); ?></th><th><?php echo e(__('Hours')); ?></th><th><?php echo e(__('Slot')); ?></th><th><?php echo e(__('Weekly limit')); ?></th><th><?php echo e(__('Approval')); ?></th><th><?php echo e(__('Status')); ?></th><th class="text-end"><?php echo e(__('Action')); ?></th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="fw-semibold"><?php echo e($facility->name); ?></td>
                                    <td><?php echo e(optional($facility->properties)->name ?? __('All properties')); ?></td>
                                    <td><?php echo e($facility->open_time); ?> - <?php echo e($facility->close_time); ?></td>
                                    <td><?php echo e($facility->slot_minutes); ?> <?php echo e(__('min')); ?></td>
                                    <td><?php echo e($facility->max_bookings_per_week ?: __('No limit')); ?></td>
                                    <td><?php echo e($facility->requires_approval ? __('Required') : __('Instant')); ?></td>
                                    <td><span class="badge bg-light-<?php echo e($facility->is_active ? 'success' : 'secondary'); ?>"><?php echo e($facility->is_active ? __('Open') : __('Closed')); ?></span></td>
                                    <td class="text-end">
                                        <div class="cart-action">
                                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['facility.destroy', $facility->id]]); ?>

                                            <a class="avtar avtar-xs btn-link-secondary text-secondary customModal" href="#" data-size="lg" data-url="<?php echo e(route('facility.edit', $facility->id)); ?>" data-title="<?php echo e(__('Edit Facility')); ?>"><i data-feather="edit"></i></a>
                                            <a class="avtar avtar-xs btn-link-danger text-danger confirm_dialog" href="#"><i data-feather="trash-2"></i></a>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="8" class="text-center text-muted"><?php echo e(__('No facilities yet. Add the gym, party hall, guest room or any shared space tenants can book.')); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h5 class="mb-0"><?php echo e(__('Upcoming bookings')); ?></h5></div>
                <div class="card-body pt-0">
                    <table class="table mb-0">
                        <thead><tr><th><?php echo e(__('Date')); ?></th><th><?php echo e(__('Time')); ?></th><th><?php echo e(__('Facility')); ?></th><th><?php echo e(__('Tenant')); ?></th><th class="text-end"></th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(dateFormat($booking->booking_date)); ?></td>
                                    <td><?php echo e($booking->start_time); ?> - <?php echo e($booking->end_time); ?></td>
                                    <td><?php echo e(optional($booking->facility)->name); ?></td>
                                    <td><?php echo e(optional(optional($booking->tenants)->user)->name); ?> <small class="text-muted"><?php echo e(optional(optional($booking->tenants)->units)->name); ?></small></td>
                                    <td class="text-end">
                                        <?php echo e(Form::open(['route' => ['facility.booking.cancel', $booking->id], 'method' => 'post', 'onsubmit' => "return confirm('" . __('Cancel this booking?') . "')"])); ?>

                                        <button class="btn btn-sm btn-light-danger"><?php echo e(__('Cancel')); ?></button>
                                        <?php echo e(Form::close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center text-muted"><?php echo e(__('No upcoming bookings.')); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/facility/index.blade.php ENDPATH**/ ?>