<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('My Parking')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('My Parking')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div class="text-muted small"><?php echo e(optional(optional($a->slot)->properties)->name); ?></div>
                        <div class="display-6 fw-bold my-2"><?php echo e(optional($a->slot)->code); ?></div>
                        <div><?php echo e(\App\Models\ParkingSlot::vehicleTypes()[optional($a->slot)->vehicle_type] ?? ''); ?></div>
                        <?php if($a->vehicle_number): ?><div class="badge bg-light-secondary mt-2 fs-6"><?php echo e($a->vehicle_number); ?></div><?php endif; ?>
                        <div class="text-muted small mt-2"><?php echo e(__('Since')); ?> <?php echo e(dateFormat($a->start_date)); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12"><div class="card"><div class="card-body text-muted"><?php echo e(__('You do not have a parking slot. Contact the office to request one.')); ?></div></div></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/parking/tenant.blade.php ENDPATH**/ ?>