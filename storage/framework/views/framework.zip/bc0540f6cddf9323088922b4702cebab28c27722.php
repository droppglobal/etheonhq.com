<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Write a Review')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Write a Review')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8 col-xl-6">
            <div class="card">
                <div class="card-header">
                    <h5><?php echo e(__('How is it living here?')); ?></h5>
                    <small class="text-muted"><?php echo e(__('Your review may be shown on our website after we read it. Please do not include private details.')); ?></small>
                </div>
                <div class="card-body">
                    <?php if($review): ?>
                        <div class="alert alert-<?php echo e($review->status === 'approved' ? 'success' : 'info'); ?> small">
                            <?php echo e($review->status === 'approved' ? __('Your review is shown on the website. Saving changes sends it for approval again.') : __('Your review is waiting for approval. You can still change it.')); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo Form::open(['route' => 'my-review.save', 'method' => 'POST']); ?>

                    <div class="form-group mb-3">
                        <label class="form-label d-block"><?php echo e(__('Rating')); ?></label>
                        <div class="st-rating" role="radiogroup" aria-label="<?php echo e(__('Rating')); ?>">
                            <?php for($i = 5; $i >= 1; $i--): ?>
                                <input type="radio" name="rating" id="rate<?php echo e($i); ?>" value="<?php echo e($i); ?>" <?php echo e((int) old('rating', $review->rating ?? 5) === $i ? 'checked' : ''); ?>>
                                <label for="rate<?php echo e($i); ?>" title="<?php echo e(__(':count out of 5', ['count' => $i])); ?>"><i class="fas fa-star"></i></label>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="review"><?php echo e(__('Your review')); ?></label>
                        <textarea class="form-control" id="review" name="review" rows="5" maxlength="1000" required><?php echo e(old('review', $review->review ?? '')); ?></textarea>
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label" for="name"><?php echo e(__('Name to show')); ?></label>
                        <input type="text" class="form-control" id="name" name="name" maxlength="80" required value="<?php echo e(old('name', $review->name ?? (\Auth::user()->first_name ? \Auth::user()->first_name . ' ' . mb_substr((string) \Auth::user()->last_name, 0, 1) . '.' : ''))); ?>">
                        <small class="text-muted"><?php echo e(__('For example your first name and the first letter of your last name.')); ?></small>
                    </div>
                    <button type="submit" class="btn btn-secondary"><?php echo e(__('Send review')); ?></button>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css-page'); ?>
    <style>
        .st-rating { display: inline-flex; flex-direction: row-reverse; gap: 4px; }
        .st-rating input { position: absolute; opacity: 0; width: 1px; height: 1px; }
        .st-rating label { font-size: 28px; color: #d1d5db; cursor: pointer; }
        .st-rating input:checked ~ label, .st-rating label:hover, .st-rating label:hover ~ label { color: #f59e0b; }
        .st-rating input:focus-visible + label { outline: 2px solid #f59e0b; border-radius: 4px; }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/website_reviews/mine.blade.php ENDPATH**/ ?>