
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/jquery-migrate-3.5.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/jquery.mmenu.all.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/ace-responsive-menu.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/jquery-scrolltofixed-min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/isotop.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/notifier.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/web/js/website.js')); ?>?v=3.7.8"></script>
<?php echo $__env->yieldPushContent('script-page'); ?>

<script>
    var successImg = '<?php echo e(asset('assets/images/notification/ok-48.png')); ?>';
    var errorImg = '<?php echo e(asset('assets/images/notification/high_priority-48.png')); ?>';
</script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<?php if($statusMessage = Session::get('success')): ?>
    <script>notifier.show(<?php echo json_encode(__('Success!'), 15, 512) ?>, <?php echo json_encode(strip_tags($statusMessage), 15, 512) ?>, 'success', successImg, 4000);</script>
<?php endif; ?>
<?php if($statusMessage = Session::get('error')): ?>
    <script>notifier.show(<?php echo json_encode(__('Error!'), 15, 512) ?>, <?php echo json_encode(strip_tags($statusMessage), 15, 512) ?>, 'error', errorImg, 4000);</script>
<?php endif; ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/scripts.blade.php ENDPATH**/ ?>