<?php if(!empty($facility)): ?>
    <?php echo e(Form::model($facility, ['route' => ['facility.update', $facility->id], 'method' => 'PUT'])); ?>

<?php else: ?>
    <?php echo e(Form::open(['route' => 'facility.store', 'method' => 'post'])); ?>

<?php endif; ?>
<div class="modal-body">
    <div class="row">
        <div class="form-group col-md-6">
            <?php echo e(Form::label('name', __('Name'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => __('e.g. Gym, Party Hall')])); ?>

        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('property_id', __('Property'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::select('property_id', $properties, null, ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group col-md-4">
            <?php echo e(Form::label('open_time', __('Opens'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::time('open_time', null, ['class' => 'form-control', 'required' => 'required'])); ?>

        </div>
        <div class="form-group col-md-4">
            <?php echo e(Form::label('close_time', __('Closes'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::time('close_time', null, ['class' => 'form-control', 'required' => 'required'])); ?>

        </div>
        <div class="form-group col-md-4">
            <?php echo e(Form::label('slot_minutes', __('Slot length (minutes)'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('slot_minutes', optional($facility)->slot_minutes ?? 60, ['class' => 'form-control', 'min' => 15, 'step' => 15, 'required' => 'required'])); ?>

        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('max_bookings_per_week', __('Max bookings per tenant per week'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('max_bookings_per_week', optional($facility)->max_bookings_per_week ?? 0, ['class' => 'form-control', 'min' => 0])); ?>

            <small class="text-muted"><?php echo e(__('0 = no limit')); ?></small>
        </div>
        <div class="form-group col-md-6 pt-md-4">
            <label class="d-block"><input type="checkbox" name="requires_approval" value="1" <?php echo e(optional($facility)->requires_approval ? 'checked' : ''); ?>> <?php echo e(__('Bookings need my approval')); ?></label>
            <?php if(!empty($facility)): ?>
                <label class="d-block"><input type="checkbox" name="is_active" value="1" <?php echo e($facility->is_active ? 'checked' : ''); ?>> <?php echo e(__('Open for booking')); ?></label>
            <?php endif; ?>
        </div>
        <div class="form-group col-md-12">
            <?php echo e(Form::label('description', __('Rules / Description'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2])); ?>

        </div>
    </div>
</div>
<div class="modal-footer">
    <?php echo e(Form::submit(!empty($facility) ? __('Update') : __('Create'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

</div>
<?php echo e(Form::close()); ?>

<?php /**PATH /home/etheonbe/public_html/resources/views/facility/form.blade.php ENDPATH**/ ?>