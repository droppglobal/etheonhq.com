<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Assistant')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Assistant')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css-page'); ?>
    <style>
        .chat-box { height: 55vh; overflow-y: auto; background: #f8f9fb; border-radius: 10px; padding: 16px; }
        .chat-msg { width: fit-content; max-width: 80%; padding: 10px 14px; border-radius: 14px; margin-bottom: 10px; white-space: pre-line; }
        .chat-msg.user { background: var(--bs-secondary, #2ca58d); color: #fff; margin-left: auto; border-bottom-right-radius: 4px; }
        .chat-msg.assistant { background: #fff; border: 1px solid #e6e8ee; border-bottom-left-radius: 4px; }
        .chat-msg.staff { background: #fff8e6; border: 1px solid #f3dfa8; border-bottom-left-radius: 4px; }
        .chat-msg .chat-who { display: block; font-size: 11px; font-weight: 600; color: #b07d10; margin-bottom: 2px; }
        .chat-chips .btn { margin: 0 6px 6px 0; }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0"><i class="ti ti-messages"></i> <?php echo e(__('Ask about your tenancy')); ?></h5>
                        <small class="text-muted"><?php echo e($aiEnabled ? __('Answers come from your own account details.') : __('Quick answers about your balance, lease and repairs.')); ?></small>
                    </div>
                    <a href="<?php echo e(route('assistant.clear')); ?>" class="btn btn-light-secondary btn-sm"><?php echo e(__('New chat')); ?></a>
                </div>
                <div class="card-body">
                    <div class="chat-box" id="chat-box">
                        <div class="chat-msg assistant"><?php echo e(__('Hi :name! How can I help? You can ask about your balance, lease or repairs, or describe a problem in your home and I can raise a maintenance request.', ['name' => \Auth::user()->first_name])); ?></div>
                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="chat-msg <?php echo e($turn->role); ?>"><?php if($turn->role == 'staff'): ?><span class="chat-who"><?php echo e(__('Property manager')); ?></span><?php endif; ?><?php echo e($turn->content); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="chat-chips mt-3">
                        <?php $__currentLoopData = [__('What do I owe?'), __('When does my lease end?'), __('Status of my repairs'), __('How do I contact the office?')]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="btn btn-light-secondary btn-sm chat-chip"><?php echo e($chip); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <form id="chat-form" class="d-flex gap-2 mt-2">
                        <input type="text" id="chat-input" class="form-control" maxlength="1000" placeholder="<?php echo e(__('Type your question...')); ?>" autocomplete="off">
                        <button type="submit" class="btn btn-secondary" id="chat-send"><i class="ti ti-send"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-page'); ?>
    <script>
        (function() {
            var $box = $('#chat-box'), $input = $('#chat-input'), $send = $('#chat-send'), lastId = <?php echo e((int) $lastId); ?>;
            function add(role, text) {
                var $m = $('<div class="chat-msg">').addClass(role).text(text);
                if (role == 'staff') $m.prepend($('<span class="chat-who">').text(<?php echo json_encode(__('Property manager'), 15, 512) ?>));
                $box.append($m).scrollTop($box[0].scrollHeight);
                return $m;
            }
            function offerRequest(description) {
                var $m = add('assistant', '<?php echo e(__('Shall I raise a maintenance request for this?')); ?>\n"' + description + '"');
                var $btn = $('<button class="btn btn-sm btn-secondary mt-2 d-block"><?php echo e(__('Yes, raise request')); ?></button>');
                $m.append($btn);
                $btn.on('click', function() {
                    $btn.prop('disabled', true);
                    $.post('<?php echo e(route('assistant.request')); ?>', { _token: '<?php echo e(csrf_token()); ?>', description: description })
                        .done(function(res) { add('assistant', res.reply); $btn.remove(); })
                        .fail(function(xhr) { add('assistant', (xhr.responseJSON && xhr.responseJSON.error) || '<?php echo e(__('Something went wrong.')); ?>'); $btn.prop('disabled', false); });
                });
            }
            function send(text) {
                text = $.trim(text);
                if (!text) return;
                add('user', text);
                $input.val(''); $send.prop('disabled', true);
                var $typing = add('assistant', '...');
                $.post('<?php echo e(route('assistant.message')); ?>', { _token: '<?php echo e(csrf_token()); ?>', message: text })
                    .done(function(res) {
                        $typing.remove();
                        add('assistant', res.reply);
                        if (res.last_id) lastId = Math.max(lastId, res.last_id);
                        if (res.suggest_request) offerRequest(res.suggest_request);
                    })
                    .fail(function(xhr) {
                        $typing.remove();
                        add('assistant', xhr.status == 429 ? '<?php echo e(__('You are sending messages too fast. Please wait a minute.')); ?>' : ((xhr.responseJSON && xhr.responseJSON.error) || '<?php echo e(__('Something went wrong.')); ?>'));
                    })
                    .always(function() { $send.prop('disabled', false); $input.focus(); });
            }
            $('#chat-form').on('submit', function(e) { e.preventDefault(); send($input.val()); });
            $('.chat-chip').on('click', function() { send($(this).text()); });
            $box.scrollTop($box[0].scrollHeight);

            // replies typed by the office appear without reloading
            setInterval(function() {
                if (document.hidden) return;
                $.getJSON('<?php echo e(route('assistant.updates')); ?>', { after: lastId }).done(function(res) {
                    (res.messages || []).forEach(function(m) { add('staff', m.content); lastId = Math.max(lastId, m.id); });
                });
            }, 20000);
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/assistant/index.blade.php ENDPATH**/ ?>