<?php
    $routeName = \Request::route()->getName();
    $c = $site->chrome;
    $wa = $site->whatsappNumber();
?>

<?php if(!empty($c['header_phone']) || $wa): ?>
    <div class="site-topbar d-none d-md-block">
        <div class="container d-flex justify-content-end gap-4 py-1 small">
            <?php if(!empty($c['header_phone'])): ?>
                <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $c['header_phone'])); ?>"><i class="fas fa-phone-alt me-1"></i> <?php echo e($c['header_phone']); ?></a>
            <?php endif; ?>
            <?php if($wa): ?>
                <a href="https://wa.me/<?php echo e($wa); ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp me-1"></i> WhatsApp</a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<header class="header-nav nav-homepage-style at-home3 stricky main-menu border-0 ">
    <nav class="posr">
        <div class="container posr">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto px-0 px-xl-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="logos">
                            <a class="header-logo logo1 landing-logo" href="<?php echo e(route('web.page', $user->code)); ?>">
                                <img src="<?php echo e($site->logo); ?>" class="img-fluid site-logo" alt="<?php echo e($site->companyName ?: __('Home')); ?>">
                            </a>
                            <a class="header-logo logo2 landing-logo" href="<?php echo e(route('web.page', $user->code)); ?>">
                                <img src="<?php echo e($site->logo); ?>" class="img-fluid site-logo" alt="<?php echo e($site->companyName ?: __('Home')); ?>">
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-auto pe-0 pe-xl-3">
                    <div class="d-flex align-items-center">
                        <ul id="respMenu" class="ace-responsive-menu" data-menu-style="horizontal">
                            <?php echo $__env->make('theme._menu', ['linkClass' => 'list-item mr5'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                        <?php if(count($site->languages) > 1): ?>
                            <div class="dropdown ms-2 site-lang">
                                <a class="dropdown-toggle small fw500" href="#" data-bs-toggle="dropdown" aria-expanded="false"><i class="far fa-globe me-1"></i><?php echo e($site->languages[$site->lang] ?? ''); ?></a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <?php $__currentLoopData = $site->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item <?php echo e($code === $site->lang ? 'active' : ''); ?>" href="<?php echo e(route('web.lang', [$user->code, $code])); ?>"><?php echo e($name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <a href="<?php echo e(route('web.saved', $user->code)); ?>" class="site-saved-link ms-2" aria-label="<?php echo e(__('Saved properties')); ?>"><i class="far fa-heart"></i><span class="site-saved-count" data-saved-count hidden>0</span></a>
                        <?php if(!empty($site->design['mode_switch'])): ?>
                            <button type="button" class="site-mode-btn ms-2" data-mode-switch="<?php echo e($user->code); ?>" aria-label="<?php echo e(__('Switch light or dark mode')); ?>"><i class="fas fa-moon"></i><i class="fas fa-sun"></i></button>
                        <?php endif; ?>
                        <?php if(!empty($c['header_button_text']) && !empty($c['header_button_link'])): ?>
                            <a href="<?php echo e($c['header_button_link']); ?>" class="ud-btn btn-thm2 site-header-btn ms-3 d-none d-xl-inline-block"><?php echo e($c['header_button_text']); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/header.blade.php ENDPATH**/ ?>