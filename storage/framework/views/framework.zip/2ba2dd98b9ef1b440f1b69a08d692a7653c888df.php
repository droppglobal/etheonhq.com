<?php
    $reviews = array_values($c['items'] ?? []);
    // approved reviews written by tenants come after the owner's own
    if (($c['include_reviews'] ?? 'active') === 'active' && !empty(\App\Support\WebsiteSite::visitors($user->id)['reviews'])) {
        foreach (\App\Models\WebsiteReview::where('parent_id', $user->id)->where('status', 'approved')->latest()->take(12)->get() as $r) {
            $reviews[] = ['review' => $r->review, 'name' => $r->name, 'tag' => $r->role ?: __('Tenant'), 'rating' => $r->rating];
        }
    }
?>
<?php if($reviews): ?>
    <section class="our-testimonial" id="<?php echo e($sectionId); ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mx-auto wow fadeInUp" data-wow-delay="300ms">
                    <div class="main-title text-center">
                        <h2><?php echo e($c['Sec7_title'] ?? ''); ?></h2>
                        <p class="paragraph"><?php echo e($c['Sec7_info'] ?? ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 m-auto wow fadeInUp" data-wow-delay="500ms">
                    <div class="testimonial-style2">
                        <div class="tab-content">
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade <?php echo e($i === 0 ? 'show active' : ''); ?>" id="<?php echo e($sectionId); ?>-t<?php echo e($i); ?>" role="tabpanel">
                                    <div class="testi-content text-center">
                                        <span class="icon fas fa-quote-left"></span>
                                        <?php if(!empty($review['rating'])): ?>
                                            <div class="site-stars mb-2" aria-label="<?php echo e(__(':count out of 5', ['count' => $review['rating']])); ?>">
                                                <?php for($s = 1; $s <= 5; $s++): ?><i class="<?php echo e($s <= $review['rating'] ? 'fas' : 'far'); ?> fa-star"></i><?php endfor; ?>
                                            </div>
                                        <?php endif; ?>
                                        <h4 class="testi-text"><?php echo e($review['review'] ?? ''); ?></h4>
                                        <h6 class="name"><?php echo e($review['name'] ?? ''); ?></h6>
                                        <p class="design"><?php echo e($review['tag'] ?? ''); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php if(count($reviews) > 1): ?>
                            <div class="tab-list">
                                <ul class="nav nav-pills justify-content-center gap-2" role="tablist">
                                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link p-1 rounded-circle border <?php echo e($i === 0 ? 'active' : ''); ?>" data-bs-toggle="pill" data-bs-target="#<?php echo e($sectionId); ?>-t<?php echo e($i); ?>" type="button" role="tab" aria-label="<?php echo e($review['name'] ?? ''); ?>">
                                                <?php if(!empty($review['image_path'])): ?>
                                                    <img src="<?php echo e(\App\Support\WebsiteImage::url($review['image_path'], 120)); ?>" alt="<?php echo e($review['name'] ?? ''); ?>" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <span class="site-avatar"><?php echo e(mb_strtoupper(mb_substr($review['name'] ?? '?', 0, 1))); ?></span>
                                                <?php endif; ?>
                                            </button>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/sections/testimonials.blade.php ENDPATH**/ ?>