<?php
    $routeName = \Request::route()->getName();
    $c = $site->chrome;
?>
<div id="page" class="mobilie_header_nav stylehome1">
    <div class="mobile-menu">
        <div class="header bdrb1">
            <div class="menu_and_widgets">
                <div class="mobile_menu_bar d-flex justify-content-between align-items-center">
                    <a class="mobile_logo" href="<?php echo e(route('web.page', $user->code)); ?>">
                        <img src="<?php echo e($site->logo); ?>" alt="<?php echo e($site->companyName); ?>" class="img-fluid" style="max-width: 200px; max-height: 48px;">
                    </a>
                    <div class="right-side text-end">
                        <a href="<?php echo e(route('web.saved', $user->code)); ?>" class="site-saved-link" aria-label="<?php echo e(__('Saved properties')); ?>"><i class="far fa-heart"></i><span class="site-saved-count" data-saved-count hidden>0</span></a>
                        <?php if(!empty($site->design['mode_switch'])): ?>
                            <button type="button" class="site-mode-btn" data-mode-switch="<?php echo e($user->code); ?>" aria-label="<?php echo e(__('Switch light or dark mode')); ?>"><i class="fas fa-moon"></i><i class="fas fa-sun"></i></button>
                        <?php endif; ?>
                        <a class="menubar ml30" href="#menu"><img src="<?php echo e(asset('assets/web/images/mobile-dark-nav-icon.svg')); ?>" alt="<?php echo e(__('Menu')); ?>"></a>
                    </div>
                </div>
            </div>
            <div class="posr">
                <div class="mobile_menu_close_btn"><span class="far fa-times"></span></div>
            </div>
        </div>
    </div>
    <nav id="menu" class="">
        <ul>
            <?php echo $__env->make('theme._menu', ['linkClass' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(!empty($c['header_button_text']) && !empty($c['header_button_link'])): ?>
                <li><a href="<?php echo e($c['header_button_link']); ?>"><?php echo e($c['header_button_text']); ?></a></li>
            <?php endif; ?>
            <?php if(count($site->languages) > 1): ?>
                <?php $__currentLoopData = $site->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('web.lang', [$user->code, $code])); ?>"><?php echo e($code === $site->lang ? '✓ ' : ''); ?><?php echo e($name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </nav>
</div>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/mobile_nav.blade.php ENDPATH**/ ?>