
<?php
    $compact = $compact ?? false;
    $f = $f ?? [];
    $val = fn($k) => $f[$k] ?? '';
    $extraUsed = collect(['type', 'bedrooms', 'min_price', 'max_price', 'available'])->contains(fn($k) => ($f[$k] ?? '') !== '');
?>
<form method="GET" action="<?php echo e(route('property.home', ['code' => $user->code])); ?>" class="site-search <?php echo e($compact ? 'site-search-compact' : ''); ?> <?php echo e($extraUsed ? 'is-open' : ''); ?>" role="search" data-search-form>
    <div class="row g-2 align-items-end">
        <div class="<?php echo e($compact ? 'col-12 col-md-4' : 'col-12 col-md-6 col-lg-3'); ?>">
            <label class="form-label" for="ss-q-<?php echo e($compact ? 'b' : 'p'); ?>"><?php echo e(__('Location or name')); ?></label>
            <input type="search" class="form-control" id="ss-q-<?php echo e($compact ? 'b' : 'p'); ?>" name="q" value="<?php echo e($val('q')); ?>" placeholder="<?php echo e(__('City, street or property')); ?>" list="ss-cities-<?php echo e($compact ? 'b' : 'p'); ?>">
            <datalist id="ss-cities-<?php echo e($compact ? 'b' : 'p'); ?>">
                <?php $__currentLoopData = $options['cities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($city); ?>"><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
        </div>
        <?php if(count($options['listings']) > 1): ?>
            <div class="<?php echo e($compact ? 'col-6 col-md-2' : 'col-6 col-md-3 col-lg-2'); ?>">
                <label class="form-label" for="ss-listing-<?php echo e($compact ? 'b' : 'p'); ?>"><?php echo e(__('Rent or buy')); ?></label>
                <select class="form-select" id="ss-listing-<?php echo e($compact ? 'b' : 'p'); ?>" name="listing">
                    <option value=""><?php echo e(__('Any')); ?></option>
                    <option value="rent" <?php if($val('listing') === 'rent'): echo 'selected'; endif; ?>><?php echo e(__('For rent')); ?></option>
                    <option value="sell" <?php if($val('listing') === 'sell'): echo 'selected'; endif; ?>><?php echo e(__('For sale')); ?></option>
                </select>
            </div>
        <?php endif; ?>
        <?php if(!$compact && count($options['types']) > 1): ?>
            <div class="col-6 col-md-3 col-lg-2 site-search-extra">
                <label class="form-label" for="ss-type"><?php echo e(__('Property type')); ?></label>
                <select class="form-select" id="ss-type" name="type">
                    <option value=""><?php echo e(__('Any')); ?></option>
                    <?php $__currentLoopData = $options['types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if($val('type') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if($options['max_bedrooms'] > 0): ?>
            <div class="<?php echo e($compact ? 'col-6 col-md-2' : 'col-6 col-md-3 col-lg-1 site-search-extra'); ?>">
                <label class="form-label" for="ss-beds-<?php echo e($compact ? 'b' : 'p'); ?>"><?php echo e(__('Bedrooms')); ?></label>
                <select class="form-select" id="ss-beds-<?php echo e($compact ? 'b' : 'p'); ?>" name="bedrooms">
                    <option value=""><?php echo e(__('Any')); ?></option>
                    <?php for($b = 1; $b <= min(6, $options['max_bedrooms']); $b++): ?>
                        <option value="<?php echo e($b); ?>" <?php if((string) $val('bedrooms') === (string) $b): echo 'selected'; endif; ?>><?php echo e($b); ?>+</option>
                    <?php endfor; ?>
                </select>
            </div>
        <?php endif; ?>
        <?php if (! ($compact)): ?>
            <div class="col-6 col-md-3 col-lg-1 site-search-extra">
                <label class="form-label" for="ss-min"><?php echo e(__('Min price')); ?></label>
                <input type="number" min="0" step="1" class="form-control" id="ss-min" name="min_price" value="<?php echo e($val('min_price')); ?>" inputmode="numeric">
            </div>
        <?php endif; ?>
        <div class="<?php echo e($compact ? 'col-6 col-md-2' : 'col-6 col-md-3 col-lg-1 site-search-extra'); ?>">
            <label class="form-label" for="ss-max-<?php echo e($compact ? 'b' : 'p'); ?>"><?php echo e(__('Max price')); ?></label>
            <input type="number" min="0" step="1" class="form-control" id="ss-max-<?php echo e($compact ? 'b' : 'p'); ?>" name="max_price" value="<?php echo e($val('max_price')); ?>" inputmode="numeric">
        </div>
        <?php if (! ($compact)): ?>
            <div class="col-12 d-md-none">
                <button type="button" class="site-search-more" data-search-more aria-expanded="<?php echo e($extraUsed ? 'true' : 'false'); ?>">
                    <i class="fas fa-sliders me-1"></i><span class="when-closed"><?php echo e(__('More filters')); ?></span><span class="when-open"><?php echo e(__('Fewer filters')); ?></span>
                </button>
            </div>
        <?php endif; ?>
        <div class="<?php echo e($compact ? 'col-12 col-md-2' : 'col-12 col-md-3 col-lg-2'); ?>">
            <button type="submit" class="ud-btn btn-thm2 w-100 site-search-btn"><i class="fas fa-magnifying-glass me-1"></i> <?php echo e(__('Search')); ?></button>
        </div>
    </div>
    <?php if (! ($compact)): ?>
        <div class="d-flex flex-wrap align-items-center gap-3 mt-3">
            <div class="form-check mb-0 site-search-extra">
                <input class="form-check-input" type="checkbox" value="1" id="ss-available" name="available" <?php if($val('available')): echo 'checked'; endif; ?>>
                <label class="form-check-label" for="ss-available"><?php echo e(__('Only with free units')); ?></label>
            </div>
            <div class="d-flex align-items-center gap-2 ms-md-auto">
                <label class="form-label mb-0 text-nowrap" for="ss-sort"><?php echo e(__('Sort by')); ?></label>
                <select class="form-select form-select-sm" id="ss-sort" name="sort">
                    <?php $__currentLoopData = \App\Support\PropertySearch::sorts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if(($val('sort') ?: 'newest') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php if(\App\Support\PropertySearch::active($f)): ?>
                <a href="<?php echo e(route('property.home', ['code' => $user->code])); ?>" class="small" data-search-reset><?php echo e(__('Clear filters')); ?></a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</form>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/_search_form.blade.php ENDPATH**/ ?>