
<?php
    $gaId = $site->seo['ga_id'] ?? '';
    $pixelId = $site->seo['pixel_id'] ?? '';
    $needsConsent = ($site->chrome['cookie_banner'] ?? 'deactive') === 'active';
?>
<?php if($gaId || $pixelId): ?>
    <script>
        window.siteAnalytics = function () {
            if (window.siteAnalyticsStarted) return;
            window.siteAnalyticsStarted = true;
            <?php if($gaId): ?>
                var s = document.createElement('script');
                s.async = true;
                s.src = 'https://www.googletagmanager.com/gtag/js?id=' + <?php echo json_encode($gaId, 15, 512) ?>;
                document.head.appendChild(s);
                window.dataLayer = window.dataLayer || [];
                window.gtag = function () { dataLayer.push(arguments); };
                gtag('js', new Date());
                gtag('config', <?php echo json_encode($gaId, 15, 512) ?>);
            <?php endif; ?>
            <?php if($pixelId): ?>
                !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
                fbq('init', <?php echo json_encode($pixelId, 15, 512) ?>);
                fbq('track', 'PageView');
            <?php endif; ?>
        };
        <?php if($needsConsent): ?>
            try { if (localStorage.getItem('site-cookies-<?php echo e($user->code); ?>')) window.siteAnalytics(); } catch (e) {}
        <?php else: ?>
            window.siteAnalytics();
        <?php endif; ?>
    </script>
<?php endif; ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/_analytics.blade.php ENDPATH**/ ?>