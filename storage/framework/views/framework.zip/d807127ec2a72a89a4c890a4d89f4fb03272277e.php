<?php
    $icons = ['flaticon-working', 'flaticon-star-2', 'flaticon-file', 'flaticon-rocket-1'];
    $stats = collect($c['items'] ?? [])->map(function ($item) use ($user) {
        $source = $item['source'] ?? 'manual';
        $value = $source === 'manual' ? ($item['number'] ?? '') : \App\Support\WebsiteSections::statValue($user->id, $source);
        return ['title' => $item['title'] ?? '', 'value' => $value, 'suffix' => $item['suffix'] ?? ''];
    })->filter(fn($s) => $s['title'] !== '' || $s['value'] !== '');
    $col = max(3, intdiv(12, max(1, min(4, $stats->count()))));
?>
<?php if($stats->isNotEmpty()): ?>
    <section class="home11-funfact bdrs12 mx-auto maxw1700" id="<?php echo e($sectionId); ?>">
        <div class="container">
            <div class="row">
                <div class="col-xl-10 mx-auto">
                    <div class="row justify-content-center wow fadeInUp" data-wow-delay="300ms">
                        <?php $__currentLoopData = $stats->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-<?php echo e($col); ?> mb-3">
                                <div class="funfact_one mb20-sm text-center">
                                    <span class="icon text-white <?php echo e($icons[$i % 4]); ?>"></span>
                                    <div class="details">
                                        <ul class="ps-0 mb-1 d-flex justify-content-center">
                                            <li><div class="timer text-white"><?php echo e($stat['value']); ?><?php echo e($stat['suffix']); ?></div></li>
                                        </ul>
                                        <p class="text text-white mb-0"><?php echo e($stat['title']); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/sections/stats.blade.php ENDPATH**/ ?>