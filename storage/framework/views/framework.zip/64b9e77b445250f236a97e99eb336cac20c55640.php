<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Visitor Passes')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Visitor Passes')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header"><h5 class="mb-0"><?php echo e(__('Expecting a visitor?')); ?></h5></div>
                <div class="card-body">
                    <?php echo e(Form::open(['route' => 'visitor.store', 'method' => 'post'])); ?>

                    <div class="form-group"><?php echo e(Form::label('visitor_name', __('Visitor name'), ['class' => 'form-label'])); ?><?php echo e(Form::text('visitor_name', null, ['class' => 'form-control', 'required' => 'required'])); ?></div>
                    <div class="form-group"><?php echo e(Form::label('visitor_phone', __('Phone'), ['class' => 'form-label'])); ?><?php echo e(Form::text('visitor_phone', null, ['class' => 'form-control'])); ?></div>
                    <div class="form-group"><?php echo e(Form::label('visit_date', __('Date'), ['class' => 'form-label'])); ?><?php echo e(Form::date('visit_date', date('Y-m-d'), ['class' => 'form-control', 'min' => date('Y-m-d'), 'required' => 'required'])); ?></div>
                    <div class="form-group"><?php echo e(Form::label('purpose', __('Purpose'), ['class' => 'form-label'])); ?><?php echo e(Form::text('purpose', null, ['class' => 'form-control', 'placeholder' => __('Guest, delivery, repair...')])); ?></div>
                    <div class="form-group"><?php echo e(Form::label('vehicle_number', __('Vehicle number (optional)'), ['class' => 'form-label'])); ?><?php echo e(Form::text('vehicle_number', null, ['class' => 'form-control'])); ?></div>
                    <button type="submit" class="btn btn-secondary w-100"><?php echo e(__('Create Pass')); ?></button>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header"><h5 class="mb-0"><?php echo e(__('My visitors')); ?></h5></div>
                <div class="card-body pt-0">
                    <table class="table mb-0">
                        <thead><tr><th><?php echo e(__('Visitor')); ?></th><th><?php echo e(__('Date')); ?></th><th><?php echo e(__('Code')); ?></th><th><?php echo e(__('Status')); ?></th><th></th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $passes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="fw-semibold"><?php echo e($pass->visitor_name); ?><br><small class="text-muted"><?php echo e($pass->purpose); ?></small></td>
                                    <td><?php echo e(dateFormat($pass->visit_date)); ?></td>
                                    <td><span class="fs-5 fw-bold font-monospace"><?php echo e($pass->code); ?></span></td>
                                    <td><span class="badge bg-light-<?php echo e(\App\Models\VisitorPass::statusColor($pass->status)); ?>"><?php echo e(\App\Models\VisitorPass::statuses()[$pass->status] ?? $pass->status); ?></span>
                                        <?php if($pass->checked_in_at): ?><br><small class="text-muted"><?php echo e(__('in')); ?> <?php echo e(timeFormat($pass->checked_in_at)); ?><?php echo e($pass->checked_out_at ? ' · ' . __('out') . ' ' . timeFormat($pass->checked_out_at) : ''); ?></small><?php endif; ?></td>
                                    <td class="text-end">
                                        <?php if($pass->status == 'active'): ?>
                                            <?php echo e(Form::open(['route' => ['visitor.cancel', $pass->id], 'method' => 'post'])); ?>

                                            <button class="btn btn-sm btn-light-danger"><?php echo e(__('Cancel')); ?></button>
                                            <?php echo e(Form::close()); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-muted"><?php echo e(__('No visitor passes yet. Create one and share the code with your visitor to show at the gate.')); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/visitor/tenant.blade.php ENDPATH**/ ?>