<section class="site-listings" id="<?php echo e($sectionId); ?>">
    <div class="container">
        <div class="row align-items-center wow fadeInUp">
            <div class="col-lg-7">
                <div class="main-title mb30-lg">
                    <h2 class="title"><?php echo e($c['Sec5_title'] ?? ''); ?></h2>
                    <p class="paragraph"><?php echo e($c['Sec5_info'] ?? ''); ?></p>
                </div>
            </div>
            <div class="col-lg-5">
                <?php if(count($listingTypes) > 1): ?>
                    <div class="navpill-style2 at-home6 mb50-lg">
                        <ul class="nav nav-pills mb20 justify-content-lg-end" role="tablist">
                            <?php $__currentLoopData = $listingTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link <?php echo e($key == 0 ? 'active' : ''); ?> fw500 dark-color" id="pills-<?php echo e($type); ?>-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-<?php echo e($type); ?>" type="button" role="tab"><?php echo e($type === 'sell' ? __('For sale') : __('For rent')); ?></button>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php if(count($listingTypes)): ?>
            <div class="tab-content ha">
                <?php $__currentLoopData = $listingTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade <?php echo e($key == 0 ? 'show active' : ''); ?>" id="pills-<?php echo e($type); ?>" role="tabpanel">
                        <div class="row">
                            <?php $__currentLoopData = $propertiesByType[$type]->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <?php echo $__env->make('theme._property_card', ['property' => $property], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-2">
                <a href="<?php echo e(route('property.home', ['code' => $user->code])); ?>" class="ud-btn btn-white2"><?php echo e(__('View all properties')); ?> <i class="fal fa-arrow-right-long"></i></a>
            </div>
        <?php else: ?>
            <p class="text-center text-muted"><?php echo e(__('New properties are coming soon.')); ?></p>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/sections/listings.blade.php ENDPATH**/ ?>