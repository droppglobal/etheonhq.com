<section class="site-section site-about" id="<?php echo e($sectionId); ?>">
    <div class="container">
        <div class="row align-items-center g-5 wow fadeInUp">
            <div class="<?php echo e(!empty($c['about_image_path']) ? 'col-lg-6' : 'col-lg-8 mx-auto'); ?>">
                <div class="main-title mb30">
                    <h2 class="title"><?php echo e($c['Sec4_title'] ?? ''); ?></h2>
                </div>
                <div class="why-chose-list">
                    <?php $__currentLoopData = $c['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-one d-flex align-items-start mb30">
                            <span class="list-icon flex-shrink-0 flaticon-badge"></span>
                            <div class="list-content flex-grow-1 ml20">
                                <h4 class="mb-1"><?php echo e($item['title'] ?? ''); ?></h4>
                                <p class="text mb-0 fz15"><?php echo e($item['subtitle'] ?? ''); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php if(!empty($c['about_image_path'])): ?>
                <div class="col-lg-6">
                    <img class="site-about-img" src="<?php echo e(\App\Support\WebsiteImage::url($c['about_image_path'], 900)); ?>" alt="<?php echo e($c['Sec4_title'] ?? ''); ?>" loading="lazy">
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/sections/about.blade.php ENDPATH**/ ?>