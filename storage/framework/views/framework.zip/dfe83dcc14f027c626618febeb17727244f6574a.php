
<?php
    $c = $site->chrome;
    $items = [];
    if ($site->menuEnabled('show_home')) $items[] = [route('web.page', $user->code), __('Home'), ['web.page']];
    if ($site->menuEnabled('show_properties')) $items[] = [route('property.home', ['code' => $user->code]), __('Properties'), ['property.home', 'property.detail', 'search.filter']];
    foreach ($site->menuPages as $p) $items[] = [route('web.custom.page', [$user->code, $p['slug']]), $p['title'], [], request()->route('slug') === $p['slug']];
    if ($site->menuEnabled('show_blog')) $items[] = [route('blog.home', ['code' => $user->code]), __('Blog'), ['blog.home', 'blog.detail']];
    foreach ((array) ($c['items'] ?? []) as $link) {
        if (!empty($link['label']) && !empty($link['link'])) $items[] = [$link['link'], $link['label'], [], false, true];
    }
    if ($site->menuEnabled('show_contact')) $items[] = [route('contact.home', ['code' => $user->code]), __('Contact'), ['contact.home']];
?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $active = in_array($routeName, $item[2]) || !empty($item[3]); ?>
    <li>
        <a class="<?php echo e($linkClass ?? ''); ?> <?php echo e($active ? 'active custom-active-style' : ''); ?>" href="<?php echo e($item[0]); ?>"
            <?php if(!empty($item[4]) && \Illuminate\Support\Str::startsWith($item[0], 'http')): ?> target="_blank" rel="noopener" <?php endif; ?>><?php echo e($item[1]); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/_menu.blade.php ENDPATH**/ ?>