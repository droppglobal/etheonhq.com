<?php $total = max(1, array_sum($results->toArray())); ?>
<?php $__currentLoopData = $poll->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $count = $results[$option->id] ?? 0; $pct = round($count / $total * 100); ?>
    <div class="mb-2">
        <div class="d-flex justify-content-between small" style="text-transform:none"><span class="<?php echo e(!empty($mine) && $mine == $option->id ? 'fw-bold' : ''); ?>"><?php echo e($option->label); ?><?php echo e(!empty($mine) && $mine == $option->id ? ' ✓' : ''); ?></span><span><?php echo e($count); ?> (<?php echo e($pct); ?>%)</span></div>
        <div class="progress" style="height:8px"><div class="progress-bar bg-secondary" style="width: <?php echo e($pct); ?>%"></div></div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/poll/_results.blade.php ENDPATH**/ ?>