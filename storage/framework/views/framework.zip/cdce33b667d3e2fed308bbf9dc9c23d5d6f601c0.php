<?php
    $site = \App\Support\WebsiteSite::for($user);
    $facts = \App\Support\PropertySearch::facts($property, $site->featuredIds());
    $photos = collect([optional($property->thumbnail)->image ? 'upload/property/thumbnail/' . $property->thumbnail->image : null])
        ->merge($property->propertyImages->map(fn($i) => $i->image ? 'upload/property/image/' . $i->image : null))
        ->filter()->unique()->values();
    if ($photos->isEmpty()) {
        $photos = collect(['upload/property/thumbnail/default.jpg']);
    }
    $type = \App\Models\Property::types()[$property->type] ?? '';
    $isRent = $property->listing_type !== 'sell';
    $place = trim(implode(', ', array_filter([$property->city, $property->state])));
    $fullAddress = trim(implode(', ', array_filter([$property->address, $property->city, $property->state, $property->zip_code, $property->country])));
    $mapLink = $property->map_link && preg_match('#^https?://#i', $property->map_link) ? $property->map_link : 'https://www.google.com/maps/search/?api=1&query=' . urlencode($fullAddress);
    $phone = $site->chrome['header_phone'] ?? ($site->chrome['footer_phone'] ?? '');
    $wa = $site->whatsappNumber();
    $pageUrl = url()->current();
    $freeUnits = $units->filter(fn($u) => (string) $u->is_occupied === '0');
    $kitchens = $units->pluck('kitchen')->filter();
    $slots = \App\Support\ViewingSlots::free($user->id);
    $site->setMeta([
        'description' => $property->description ?: trim(($isRent ? __('For rent') : __('For sale')) . ' · ' . $place),
        'image' => asset(Storage::url($photos->first())),
        'type' => 'article',
    ]);
    $listing = array_filter([
        '@context' => 'https://schema.org',
        '@type' => 'RealEstateListing',
        'name' => $property->name,
        'url' => $site->canonical(),
        'description' => $site->metaDescription(),
        'image' => $photos->take(6)->map(fn($p) => \App\Support\WebsiteSite::safeUrl(asset(Storage::url($p))))->values()->all(),
        'datePosted' => optional($property->created_at)->toDateString(),
        'offers' => $property->price ? ['@type' => 'Offer', 'price' => (float) $property->price, 'priceCurrency' => strtoupper(substr((string) (settingsById($user->id)['CURRENCY'] ?? 'USD'), 0, 3)) ?: 'USD',
            'availability' => $isRent && $freeUnits->isEmpty() && $units->isNotEmpty() ? 'https://schema.org/SoldOut' : 'https://schema.org/InStock'] : null,
        'address' => array_filter(['@type' => 'PostalAddress', 'streetAddress' => $property->address, 'addressLocality' => $property->city, 'addressRegion' => $property->state, 'postalCode' => $property->zip_code, 'addressCountry' => $property->country]),
    ]);
    $crumbs = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
        ['@type' => 'ListItem', 'position' => 1, 'name' => __('Home'), 'item' => $site->canonical(route('web.page', $user->code))],
        ['@type' => 'ListItem', 'position' => 2, 'name' => __('Properties'), 'item' => $site->canonical(route('property.home', ['code' => $user->code]))],
        ['@type' => 'ListItem', 'position' => 3, 'name' => $property->name],
    ]];
?>
<?php $__env->startPush('schema'); ?>
    <script type="application/ld+json"><?php echo json_encode($listing, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?></script>
    <script type="application/ld+json"><?php echo json_encode($crumbs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-title', ucfirst($property->name) . ($place ? ', ' . $place : '') . ' – ' . $site->siteName); ?>
<?php $__env->startSection('content'); ?>
    <section class="site-detail-head">
        <div class="container">
            <nav aria-label="<?php echo e(__('Breadcrumb')); ?>" class="site-crumbs">
                <a href="<?php echo e(route('web.page', $user->code)); ?>"><?php echo e(__('Home')); ?></a>
                <span aria-hidden="true">/</span>
                <a href="<?php echo e(route('property.home', ['code' => $user->code])); ?>"><?php echo e(__('Properties')); ?></a>
                <span aria-hidden="true">/</span>
                <span aria-current="page"><?php echo e(ucfirst($property->name)); ?></span>
            </nav>
            <div class="d-flex flex-wrap justify-content-between align-items-end gap-3">
                <div>
                    <div class="site-tags position-static mb-2">
                        <span class="site-tag site-tag-<?php echo e($isRent ? 'rent' : 'sale'); ?>"><?php echo e($isRent ? __('For rent') : __('For sale')); ?></span>
                        <?php $__currentLoopData = $facts['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$key, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="site-tag site-tag-<?php echo e($key); ?>"><?php echo e($label); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <h1 class="site-detail-title"><?php echo e(ucfirst($property->name)); ?></h1>
                    <?php if($place): ?><p class="text-muted mb-0"><i class="fas fa-map-marker-alt me-1"></i><?php echo e($place); ?></p><?php endif; ?>
                </div>
                <?php if($property->price): ?>
                    <div class="site-detail-price">
                        <small><?php echo e($isRent ? __('Rent') : __('Price')); ?></small>
                        <strong><?php echo e(\App\Support\WebsiteSite::price($property->price)); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    
    <div class="container" data-lightbox>
        <div class="site-gallery site-gallery-<?php echo e(min(5, $photos->count())); ?>">
            <?php $__currentLoopData = $photos->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset(Storage::url($photo))); ?>" class="site-gallery-item" data-lightbox-item="<?php echo e($i); ?>" aria-label="<?php echo e(__('Open photo :n of :total', ['n' => $i + 1, 'total' => $photos->count()])); ?>">
                    <img src="<?php echo e(\App\Support\WebsiteImage::url($photo, $i ? 640 : 1280)); ?>" decoding="async" alt="<?php echo e($property->name); ?> – <?php echo e(__('photo')); ?> <?php echo e($i + 1); ?>" <?php echo e($i ? 'loading=lazy' : ''); ?>>
                    <?php if($i === 4 && $photos->count() > 5): ?>
                        <span class="site-gallery-more">+<?php echo e($photos->count() - 5); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $photos->slice(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset(Storage::url($photo))); ?>" class="d-none" data-lightbox-item="<?php echo e($i); ?>" tabindex="-1" aria-hidden="true"></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($photos->count() > 1): ?>
            <button type="button" class="site-gallery-all" data-lightbox-open><i class="fas fa-images me-1"></i> <?php echo e(__('Show all photos (:count)', ['count' => $photos->count()])); ?></button>
        <?php endif; ?>
    </div>

    <section class="site-section pt-4 site-detail-body">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-8">
                    
                    <ul class="site-keyfacts">
                        <?php if($type): ?><li><i class="fas fa-building"></i><span><?php echo e(__('Type')); ?></span><strong><?php echo e($type); ?></strong></li><?php endif; ?>
                        <?php if($facts['beds'] !== ''): ?><li><i class="fas fa-bed"></i><span><?php echo e(__('Bedrooms')); ?></span><strong><?php echo e($facts['beds']); ?></strong></li><?php endif; ?>
                        <?php if($facts['baths'] !== ''): ?><li><i class="fas fa-bath"></i><span><?php echo e(__('Bathrooms')); ?></span><strong><?php echo e($facts['baths']); ?></strong></li><?php endif; ?>
                        <?php if($kitchens->count()): ?><li><i class="fas fa-utensils"></i><span><?php echo e(__('Kitchens')); ?></span><strong><?php echo e($kitchens->min() == $kitchens->max() ? $kitchens->max() : $kitchens->min() . '–' . $kitchens->max()); ?></strong></li><?php endif; ?>
                        <?php if($facts['units']): ?><li><i class="fas fa-door-open"></i><span><?php echo e(__('Units')); ?></span><strong><?php echo e($facts['units']); ?></strong></li><?php endif; ?>
                        <?php if($isRent && $facts['units']): ?><li><i class="fas fa-circle-check"></i><span><?php echo e(__('Available')); ?></span><strong><?php echo e($facts['vacant']); ?></strong></li><?php endif; ?>
                    </ul>

                    <?php if(trim(strip_tags((string) $property->description)) !== ''): ?>
                        <div class="site-block">
                            <h2 class="site-block-title"><?php echo e(__('About this property')); ?></h2>
                            <div class="property-description"><?php echo \App\Support\WebsiteSite::cleanHtml($property->description); ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if($selectedAmenities->count()): ?>
                        <div class="site-block">
                            <h2 class="site-block-title"><?php echo e(__('Amenities')); ?></h2>
                            <div class="row g-3">
                                <?php $__currentLoopData = $selectedAmenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4">
                                        <div class="site-amenity">
                                            <?php if($amenity->image): ?>
                                                <img src="<?php echo e(fetch_file('upload/amenity/' . $amenity->image)); ?>" alt="" loading="lazy">
                                            <?php else: ?>
                                                <i class="fas fa-check"></i>
                                            <?php endif; ?>
                                            <span><?php echo e($amenity->name); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($selectedAdvantages->count()): ?>
                        <div class="site-block">
                            <h2 class="site-block-title"><?php echo e(__('Advantages')); ?></h2>
                            <ul class="site-checklist">
                                <?php $__currentLoopData = $selectedAdvantages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advantage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><i class="fas fa-check-circle"></i> <?php echo e($advantage->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if($units->isNotEmpty()): ?>
                        <div class="site-block">
                            <h2 class="site-block-title"><?php echo e(__('Units')); ?></h2>
                            <div class="row g-3">
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $free = (string) $unit->is_occupied === '0'; ?>
                                    <div class="col-md-6">
                                        <div class="site-unit <?php echo e($free ? 'is-free' : ''); ?>">
                                            <div class="d-flex justify-content-between align-items-start mb-2">
                                                <h3 class="h6 mb-0"><?php echo e(ucfirst($unit->name)); ?></h3>
                                                <?php if($isRent): ?>
                                                    <span class="site-unit-status"><?php echo e($free ? __('Available') : __('Let')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <ul class="site-facts border-0 pt-0">
                                                <li><i class="fas fa-bed"></i> <?php echo e((int) $unit->bedroom); ?> <span><?php echo e(__('Beds')); ?></span></li>
                                                <li><i class="fas fa-bath"></i> <?php echo e((int) $unit->baths); ?> <span><?php echo e(__('Baths')); ?></span></li>
                                                <li><i class="fas fa-utensils"></i> <?php echo e((int) $unit->kitchen); ?> <span><?php echo e(__('Kitchen')); ?></span></li>
                                            </ul>
                                            <?php if($isRent && $unit->rent > 0): ?>
                                                <p class="site-unit-rent mb-0"><?php echo e(\App\Support\WebsiteSite::price($unit->rent)); ?> <?php if($unit->rent_type): ?><small>/ <?php echo e(__(ucfirst($unit->rent_type))); ?></small><?php endif; ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($fullAddress): ?>
                        <div class="site-block">
                            <h2 class="site-block-title"><?php echo e(__('Location')); ?></h2>
                            <p class="mb-3"><i class="fas fa-map-marker-alt me-1"></i> <?php echo e($fullAddress); ?></p>
                            <div class="site-map-frame">
                                <iframe src="https://maps.google.com/maps?q=<?php echo e(urlencode($fullAddress)); ?>&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="<?php echo e(__('Map')); ?>"></iframe>
                            </div>
                            <a href="<?php echo e($mapLink); ?>" target="_blank" rel="noopener" class="d-inline-block mt-2 small"><?php echo e(__('Open in Google Maps')); ?> <i class="fas fa-up-right-from-square ms-1"></i></a>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="col-lg-4">
                    <aside class="site-enquiry" id="enquiry">
                        <?php if($property->price): ?>
                            <p class="site-enquiry-price mb-1"><?php echo e(\App\Support\WebsiteSite::price($property->price)); ?></p>
                        <?php endif; ?>
                        <?php if($isRent && $freeUnits->isNotEmpty()): ?>
                            <p class="site-card-avail mt-0 mb-3"><i class="fas fa-circle-check"></i> <?php echo e(__('Units available: :count', ['count' => $freeUnits->count()])); ?></p>
                        <?php endif; ?>
                        <h2 class="h5 mb-3"><?php echo e(__('Interested in this property?')); ?></h2>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                        <?php echo e(Form::open(['route' => ['web.enquiry', 'code' => $code], 'method' => 'post'])); ?>

                        <?php echo e(Form::hidden('property_id', $property->id)); ?>

                        <div style="position:absolute;left:-9999px" aria-hidden="true">
                            <input type="text" name="website" tabindex="-1" autocomplete="off">
                        </div>
                        <div class="mb-2">
                            <?php echo e(Form::label('name', __('Name'), ['class' => 'form-label'])); ?>

                            <?php echo e(Form::text('name', null, ['class' => 'form-control', 'required' => 'required', 'autocomplete' => 'name'])); ?>

                        </div>
                        <div class="mb-2">
                            <?php echo e(Form::label('email', __('Email'), ['class' => 'form-label'])); ?>

                            <?php echo e(Form::email('email', null, ['class' => 'form-control', 'required' => 'required', 'autocomplete' => 'email'])); ?>

                        </div>
                        <div class="mb-2">
                            <?php echo e(Form::label('phone', __('Phone'), ['class' => 'form-label'])); ?>

                            <?php echo e(Form::tel('phone', null, ['class' => 'form-control', 'autocomplete' => 'tel'])); ?>

                        </div>
                        <?php if($units->count() > 1): ?>
                            <div class="mb-2">
                                <?php echo e(Form::label('unit_id', __('Unit'), ['class' => 'form-label'])); ?>

                                <?php echo e(Form::select('unit_id', ['' => __('Any unit')] + $units->pluck('name', 'id')->toArray(), null, ['class' => 'form-select'])); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($slots): ?>
                            
                            <fieldset class="site-slots mb-2" data-slots='<?php echo json_encode($slots, 15, 512) ?>'>
                                <legend class="form-label mb-1"><?php echo e(__('Book a viewing (optional)')); ?></legend>
                                <input type="hidden" name="viewing_date" value="<?php echo e(old('viewing_date')); ?>">
                                <input type="hidden" name="viewing_time" value="<?php echo e(old('viewing_time')); ?>">
                                <div class="site-slot-days" role="listbox" aria-label="<?php echo e(__('Day')); ?>">
                                    <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $times): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $d = \Carbon\Carbon::parse($date)->locale(app()->getLocale()); ?>
                                        <button type="button" class="site-slot-day" data-date="<?php echo e($date); ?>" aria-pressed="false">
                                            <small><?php echo e($d->isoFormat('ddd')); ?></small><strong><?php echo e($d->format('j')); ?></strong><small><?php echo e($d->isoFormat('MMM')); ?></small>
                                        </button>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="site-slot-times" aria-live="polite" data-hint="<?php echo e(__('Pick a day to see free times.')); ?>"><p class="small text-muted mb-0"><?php echo e(__('Pick a day to see free times.')); ?></p></div>
                                <p class="small mb-0 mt-1 site-slot-chosen" hidden><i class="fas fa-calendar-check me-1"></i><span></span> <button type="button" class="btn btn-link btn-sm p-0 ms-1" data-slot-clear><?php echo e(__('Clear')); ?></button></p>
                            </fieldset>
                        <?php else: ?>
                            <div class="row g-2 mb-2">
                                <div class="col-7">
                                    <?php echo e(Form::label('viewing_date', __('Viewing date'), ['class' => 'form-label'])); ?>

                                    <?php echo e(Form::date('viewing_date', null, ['class' => 'form-control', 'min' => date('Y-m-d')])); ?>

                                </div>
                                <div class="col-5">
                                    <?php echo e(Form::label('viewing_time', __('Time'), ['class' => 'form-label'])); ?>

                                    <?php echo e(Form::time('viewing_time', null, ['class' => 'form-control'])); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="mb-3">
                            <?php echo e(Form::label('message', __('Message'), ['class' => 'form-label'])); ?>

                            <?php echo e(Form::textarea('message', null, ['class' => 'form-control', 'rows' => 3, 'style' => 'height:auto'])); ?>

                        </div>
                        <button type="submit" class="ud-btn btn-thm2 w-100"><?php echo e(__('Send Enquiry')); ?></button>
                        <?php echo e(Form::close()); ?>


                        <?php if($isRent && $freeUnits->isNotEmpty()): ?>
                            <a href="<?php echo e(route('web.apply', ['code' => $code, 'id' => \Crypt::encrypt($property->id)])); ?>" class="ud-btn btn-white2 w-100 mt-2"><?php echo e(__('Apply Now')); ?></a>
                        <?php endif; ?>

                        <?php if($phone || $wa): ?>
                            <div class="site-enquiry-contact">
                                <?php if($phone): ?><a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $phone)); ?>"><i class="fas fa-phone-alt"></i> <?php echo e($phone); ?></a><?php endif; ?>
                                <?php if($wa): ?><a href="https://wa.me/<?php echo e($wa); ?>?text=<?php echo e(urlencode(__('Hello, I am interested in :property', ['property' => $property->name]) . ' ' . $pageUrl)); ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> WhatsApp</a><?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <div class="site-share">
                            <span><?php echo e(__('Share')); ?>:</span>
                            <a href="https://wa.me/?text=<?php echo e(urlencode($property->name . ' ' . $pageUrl)); ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode($pageUrl)); ?>" target="_blank" rel="noopener" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                            <a href="mailto:?subject=<?php echo e(rawurlencode($property->name)); ?>&body=<?php echo e(rawurlencode($pageUrl)); ?>" aria-label="<?php echo e(__('Email')); ?>"><i class="fas fa-envelope"></i></a>
                            <button type="button" data-copy-link="<?php echo e($pageUrl); ?>" data-copied="<?php echo e(__('Link copied')); ?>" aria-label="<?php echo e(__('Copy link')); ?>"><i class="fas fa-link"></i></button>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>

    <?php if($similar->isNotEmpty()): ?>
        <section class="site-section pt-0">
            <div class="container">
                <h2 class="site-block-title mb-4"><?php echo e(__('Similar properties')); ?></h2>
                <div class="row">
                    <?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 mb-4"><?php echo $__env->make('theme._property_card', ['property' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    
    <div class="site-mobile-bar d-lg-none">
        <?php if($phone): ?><a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $phone)); ?>"><i class="fas fa-phone-alt"></i><span><?php echo e(__('Call')); ?></span></a><?php endif; ?>
        <?php if($wa): ?><a href="https://wa.me/<?php echo e($wa); ?>?text=<?php echo e(urlencode(__('Hello, I am interested in :property', ['property' => $property->name]) . ' ' . $pageUrl)); ?>" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i><span>WhatsApp</span></a><?php endif; ?>
        <a href="#enquiry" class="is-main"><i class="fas fa-envelope"></i><span><?php echo e(__('Enquire')); ?></span></a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-page'); ?>
    <script>
        (function() {
            var box = document.querySelector('[data-slots]');
            if (!box) return;
            var slots = JSON.parse(box.getAttribute('data-slots')), dateIn = box.querySelector('[name=viewing_date]'), timeIn = box.querySelector('[name=viewing_time]'),
                times = box.querySelector('.site-slot-times'), chosen = box.querySelector('.site-slot-chosen');
            function pickDay(date) {
                box.querySelectorAll('.site-slot-day').forEach(function(b) { var on = b.dataset.date === date; b.classList.toggle('active', on); b.setAttribute('aria-pressed', on); });
                times.innerHTML = '';
                (slots[date] || []).forEach(function(t) {
                    var b = document.createElement('button');
                    b.type = 'button'; b.className = 'site-slot-time'; b.textContent = t; b.setAttribute('aria-pressed', 'false');
                    b.onclick = function() { pick(date, t, b); };
                    times.appendChild(b);
                });
            }
            function pick(date, t, btn) {
                dateIn.value = date; timeIn.value = t;
                times.querySelectorAll('.site-slot-time').forEach(function(b) { var on = b === btn; b.classList.toggle('active', on); b.setAttribute('aria-pressed', on); });
                var day = box.querySelector('.site-slot-day[data-date="' + date + '"]');
                chosen.querySelector('span').textContent = day.innerText.replace(/\s+/g, ' ').trim() + ', ' + t;
                chosen.hidden = false;
            }
            box.querySelectorAll('.site-slot-day').forEach(function(b) { b.addEventListener('click', function() { pickDay(b.dataset.date); }); });
            box.querySelector('[data-slot-clear]').addEventListener('click', function() {
                dateIn.value = ''; timeIn.value = ''; chosen.hidden = true;
                times.querySelectorAll('.site-slot-time').forEach(function(b) { b.classList.remove('active'); b.setAttribute('aria-pressed', 'false'); });
            });
            // keep the earlier choice after a failed submit
            if (dateIn.value && slots[dateIn.value]) {
                pickDay(dateIn.value);
                var btn = Array.prototype.find.call(times.children, function(b) { return b.textContent === timeIn.value; });
                if (btn) pick(dateIn.value, timeIn.value, btn); else { timeIn.value = ''; }
            }
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/theme/detail.blade.php ENDPATH**/ ?>