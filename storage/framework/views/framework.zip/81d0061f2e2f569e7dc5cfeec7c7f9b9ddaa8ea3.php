<?php echo e(Form::model($unit, ['route' => ['unit.update', $property_id, $unit->id], 'method' => 'PUT'])); ?>


<div class="modal-body">
    <?php echo $__env->make('ai.writer', ['type' => 'unit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="form-group  col-md-12">
            <?php echo e(Form::label('name', __('Name'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => __('Enter unit name')])); ?>

        </div>
        <div class="form-group  col-md-4">
            <?php echo e(Form::label('bedroom', __('Bedroom'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('bedroom', null, ['class' => 'form-control', 'placeholder' => __('Enter number of bedroom')])); ?>

        </div>
        <div class="form-group  col-md-4">
            <?php echo e(Form::label('kitchen', __('Kitchen'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('kitchen', null, ['class' => 'form-control', 'placeholder' => __('Enter number of kitchen')])); ?>

        </div>
        <div class="form-group  col-md-4">
            <?php echo e(Form::label('baths', __('Bath'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('baths', null, ['class' => 'form-control', 'placeholder' => __('Enter number of bath')])); ?>

        </div>
        <div class="form-group  col-md-6">
            <?php echo e(Form::label('rent', __('Rent'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('rent', null, ['class' => 'form-control', 'placeholder' => __('Enter unit rent')])); ?>

            <?php if(!empty($rentSuggestion)): ?>
                <small class="text-muted d-block mt-1"><i class="ti ti-bulb text-warning"></i>
                    <?php echo e(__('Similar units :scope', ['scope' => $rentSuggestion['scope']])); ?>: <?php echo e(priceFormat($rentSuggestion['low'])); ?> - <?php echo e(priceFormat($rentSuggestion['high'])); ?>

                    (<?php echo e(__('median')); ?> <?php echo e(priceFormat($rentSuggestion['median'])); ?>, <?php echo e($rentSuggestion['count']); ?> <?php echo e(__('units')); ?>)</small>
            <?php endif; ?>
        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('rent_type', __('Rent Type'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::select('rent_type', $rentTypes, null, ['class' => 'form-control hidesearch', 'id' => 'rent_type'])); ?>

        </div>
        <div class="form-group  col-md-12 rent_type monthly ">
            <?php echo e(Form::label('rent_duration', __('Rent Duration'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('rent_duration', null, ['class' => 'form-control', 'placeholder' => __('Enter day of month between 1 to 30')])); ?>

        </div>
        <div class="form-group  col-md-12 rent_type yearly d-none">
            <?php echo e(Form::label('rent_duration', __('Rent Duration'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('rent_duration', null, ['class' => 'form-control', 'placeholder' => __('Enter month of year between 1 to 12'), 'disabled'])); ?>

        </div>
        <div class="form-group  col-md-4 rent_type custom d-none">
            <?php echo e(Form::label('start_date', __('Start Date'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::date('start_date', null, ['class' => 'form-control', 'disabled'])); ?>

        </div>
        <div class="form-group  col-md-4 rent_type custom d-none">
            <?php echo e(Form::label('end_date', __('End Date'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::date('end_date', null, ['class' => 'form-control', 'disabled'])); ?>

        </div>
        <div class="form-group  col-md-4 rent_type custom d-none">
            <?php echo e(Form::label('payment_due_date', __('Payment Due Date'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::date('payment_due_date', null, ['class' => 'form-control', 'disabled'])); ?>

        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('deposit_type', __('Deposit Type'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::select('deposit_type', $types, null, ['class' => 'form-control hidesearch'])); ?>

        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('deposit_amount', __('Deposit Amount'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('deposit_amount', null, ['class' => 'form-control', 'placeholder' => __('Enter deposit amount')])); ?>

        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('late_fee_type', __('Late Fee Type'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::select('late_fee_type', $types, null, ['class' => 'form-control hidesearch'])); ?>

        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('late_fee_amount', __('Late Fee Amount'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('late_fee_amount', null, ['class' => 'form-control', 'placeholder' => __('Enter late fee amount')])); ?>

        </div>
        <div class="form-group col-md-12">
            <?php echo e(Form::label('incident_receipt_amount', __('Incident Receipt Amount'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::number('incident_receipt_amount', null, ['class' => 'form-control', 'placeholder' => __('Enter incident receipt amount')])); ?>

        </div>
        <div class="form-group col-md-12">
            <?php echo e(Form::label('notes', __('Notes'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::textarea('notes', null, ['class' => 'form-control', 'rows' => 2, 'placeholder' => __('Enter notes')])); ?>

        </div>
    </div>
</div>
<div class="modal-footer">
    <?php echo e(Form::submit(__('Update'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

</div>
<?php echo e(Form::close()); ?>

<script>
    $('#rent_type').on('change', function() {
        "use strict";
        var type = this.value;
        $('.rent_type').addClass('d-none')
        $('.' + type).removeClass('d-none')

        var input1 = $('.rent_type').find('input');
        input1.prop('disabled', true);
        var input2 = $('.' + type).find('input');
        input2.prop('disabled', false);
    });
    $('#rent_type').trigger('change');
</script>
<?php /**PATH /home/etheonbe/public_html/resources/views/unit/edit.blade.php ENDPATH**/ ?>