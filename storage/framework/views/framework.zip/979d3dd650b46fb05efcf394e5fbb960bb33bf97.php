<?php echo e(Form::model($page, ['route' => ['pages.update', $page->id], 'method' => 'PUT'])); ?>

<div class="modal-body">
    <div class="row">
        <div class="form-group  col-md-12">
            <?php echo e(Form::label('title', __('Title'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::text('title', null, ['class' => 'form-control', 'placeholder' => __('Enter Title')])); ?>

        </div>
         <div class="form-group col-md-6">
            <?php echo e(Form::label('enabled', __('Enabled Page'), ['class' => 'form-label'])); ?>

            <input type="hidden" name="enabled" value="0">
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" name="enabled"
                    value="1" <?php echo e($page->enabled == 1 ? 'checked' : ''); ?>>
                <label class="form-check-label" for="flexSwitchCheckChecked"></label>
            </div>
        </div>
        <div class="form-group  col-md-12">
            <?php echo e(Form::label('content', __('Content'), ['class' => 'form-label'])); ?>

            <?php echo Form::textarea('content', null, ['class' => 'form-control', 'id' => 'classic-editor']); ?>

        </div>
    </div>
</div>
<div class="modal-footer">

    <?php echo e(Form::submit(__('Update'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

</div>
<?php echo e(Form::close()); ?>

<?php /**PATH /home/etheonbe/public_html/resources/views/Pages/edit.blade.php ENDPATH**/ ?>