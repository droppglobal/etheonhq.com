<?php echo e(Form::open(['route' => 'poll.store', 'method' => 'post'])); ?>

<div class="modal-body">
    <div class="row">
        <div class="form-group col-md-12">
            <?php echo e(Form::label('question', __('Question'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::text('question', null, ['class' => 'form-control', 'required' => 'required'])); ?>

        </div>
        <div class="form-group col-md-12">
            <?php echo e(Form::label('description', __('Details (optional)'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::textarea('description', null, ['class' => 'form-control', 'rows' => 2])); ?>

        </div>
        <div class="col-md-12"><label class="form-label"><?php echo e(__('Options')); ?></label></div>
        <?php for($i = 0; $i < 5; $i++): ?>
            <div class="form-group col-md-6">
                <?php echo e(Form::text('options[]', null, array_merge(['class' => 'form-control', 'placeholder' => __('Option') . ' ' . ($i + 1)], $i < 2 ? ['required' => 'required'] : []))); ?>

            </div>
        <?php endfor; ?>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('property_id', __('Who can vote'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::select('property_id', $properties, 0, ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group col-md-6">
            <?php echo e(Form::label('closes_on', __('Closes on (optional)'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::date('closes_on', null, ['class' => 'form-control', 'min' => date('Y-m-d')])); ?>

        </div>
        <div class="col-md-12"><label><input type="checkbox" name="show_results" value="1" checked> <?php echo e(__('Show results to tenants after they vote')); ?></label></div>
    </div>
</div>
<div class="modal-footer">
    <?php echo e(Form::submit(__('Publish'), ['class' => 'btn btn-secondary btn-rounded'])); ?>

</div>
<?php echo e(Form::close()); ?>

<?php /**PATH /home/etheonbe/public_html/resources/views/poll/form.blade.php ENDPATH**/ ?>