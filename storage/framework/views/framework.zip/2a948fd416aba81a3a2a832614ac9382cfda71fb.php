<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Polls')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Polls')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $mine = $myVotes[$poll->id] ?? null; ?>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header"><h5 class="mb-0"><?php echo e($poll->question); ?></h5>
                        <small class="text-muted"><?php echo e($poll->isOpen() ? ($poll->closes_on ? __('Closes') . ' ' . dateFormat($poll->closes_on) : __('Open')) : __('Closed')); ?></small></div>
                    <div class="card-body">
                        <?php if($poll->description): ?><p class="small"><?php echo nl2br(e($poll->description)); ?></p><?php endif; ?>
                        <?php if(!$mine && $poll->isOpen()): ?>
                            <?php echo e(Form::open(['route' => ['poll.vote', $poll->id], 'method' => 'post'])); ?>

                            <?php $__currentLoopData = $poll->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="d-block border rounded p-2 mb-2" style="text-transform:none"><input type="radio" name="option_id" value="<?php echo e($option->id); ?>" required> <?php echo e($option->label); ?></label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-secondary"><?php echo e(__('Vote')); ?></button>
                            <?php echo e(Form::close()); ?>

                        <?php elseif($poll->show_results): ?>
                            <?php echo $__env->make('poll._results', ['results' => $poll->results(), 'mine' => $mine], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                            <p class="text-muted mb-0"><?php echo e($mine ? __('Thanks, your vote is recorded.') : __('This poll is closed.')); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12"><div class="card"><div class="card-body text-muted"><?php echo e(__('No polls right now.')); ?></div></div></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/poll/tenant.blade.php ENDPATH**/ ?>