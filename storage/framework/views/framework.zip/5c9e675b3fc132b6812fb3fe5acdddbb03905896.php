<div class="card">
    <div class="card-body">
        <?php echo $page->content; ?>

    </div>
</div>
<?php /**PATH /home/etheonbe/public_html/resources/views/Pages/show.blade.php ENDPATH**/ ?>