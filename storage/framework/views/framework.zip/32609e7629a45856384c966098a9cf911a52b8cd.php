<?php
    $c = $site->chrome;
    $socials = array_filter([
        'fab fa-facebook-f' => $c['fb_link'] ?? '', 'fab fa-twitter' => $c['twitter_link'] ?? '', 'fab fa-instagram' => $c['insta_link'] ?? '',
        'fab fa-linkedin-in' => $c['linkedin_link'] ?? '', 'fab fa-youtube' => $c['youtube_link'] ?? '',
    ], fn($l) => $l !== '' && $l !== '#');
    $routeName = \Request::route()->getName();
    $wa = $site->whatsappNumber();
    $tenantLinks = ($c['show_tenant_links'] ?? 'active') === 'active';
    $appLinks = array_filter(['android' => $c['app_android'] ?? '', 'ios' => $c['app_ios'] ?? ''], fn($l) => $l !== '' && $l !== '#');
    $legal = \App\Models\WebsitePage::where('parent_id', $user->id)->where('is_active', 1)
        ->whereIn('id', array_filter([(int) ($c['privacy_page'] ?? 0), (int) ($c['terms_page'] ?? 0)]))->get()->keyBy('id');
    $legalLinks = collect(['privacy_page' => __('Privacy policy'), 'terms_page' => __('Terms')])
        ->map(fn($label, $key) => isset($legal[(int) ($c[$key] ?? 0)]) ? [$label, route('web.custom.page', [$user->code, $legal[(int) $c[$key]]->slug])] : null)->filter();
    $hasContact = !empty($c['footer_address']) || !empty($c['footer_phone']) || !empty($c['footer_email']) || !empty($c['footer_hours']) || $wa;
?>
<section class="footer-style1 site-footer pt60 pb-0">
    <div class="container">
        <div class="row pb-4">
            <div class="<?php echo e($tenantLinks || $appLinks ? 'col-lg-4' : 'col-lg-5'); ?> mb-4">
                <img src="<?php echo e($site->logo); ?>" alt="<?php echo e($site->companyName); ?>" class="site-footer-logo mb-3">
                <?php if(!empty($c['Sec8_info'])): ?>
                    <p class="text-white-light mb-3"><?php echo e($c['Sec8_info']); ?></p>
                <?php endif; ?>
                <?php if($socials): ?>
                    <div class="social-style1">
                        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($link); ?>" target="_blank" rel="noopener" class="me-2"><i class="<?php echo e($icon); ?> list-inline-item"></i></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-6 <?php echo e($tenantLinks || $appLinks ? 'col-lg-2' : 'col-lg-3'); ?> mb-4">
                <h6 class="text-white mb-3"><?php echo e(__('Quick links')); ?></h6>
                <ul class="list-unstyled site-footer-links mb-0">
                    <?php echo $__env->make('theme._menu', ['linkClass' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
            </div>
            <?php if($tenantLinks || $appLinks): ?>
                <div class="col-6 col-lg-3 mb-4">
                    <h6 class="text-white mb-3"><?php echo e(__('For tenants')); ?></h6>
                    <?php if($tenantLinks): ?>
                        <ul class="list-unstyled site-footer-links mb-3">
                            <li><a href="<?php echo e(\App\Support\WebsiteSite::appUrl('login')); ?>"><i class="fas fa-right-to-bracket me-2"></i><?php echo e(__('Tenant login')); ?></a></li>
                            <li><a href="<?php echo e(\App\Support\WebsiteSite::appUrl('invoice.index')); ?>"><i class="fas fa-credit-card me-2"></i><?php echo e(__('Pay rent')); ?></a></li>
                            <li><a href="<?php echo e(\App\Support\WebsiteSite::appUrl('maintenance-request.index')); ?>"><i class="fas fa-wrench me-2"></i><?php echo e(__('Report a repair')); ?></a></li>
                        </ul>
                    <?php endif; ?>
                    <?php if($appLinks): ?>
                        <div class="site-store-badges">
                            <?php if(!empty($appLinks['android'])): ?>
                                <a href="<?php echo e($appLinks['android']); ?>" target="_blank" rel="noopener" class="site-store-badge"><i class="fab fa-google-play"></i><span><small><?php echo e(__('Get it on')); ?></small>Google Play</span></a>
                            <?php endif; ?>
                            <?php if(!empty($appLinks['ios'])): ?>
                                <a href="<?php echo e($appLinks['ios']); ?>" target="_blank" rel="noopener" class="site-store-badge"><i class="fab fa-apple"></i><span><small><?php echo e(__('Download on the')); ?></small>App Store</span></a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if($hasContact): ?>
            <div class="col-sm-6 <?php echo e($tenantLinks || $appLinks ? 'col-lg-3' : 'col-lg-4'); ?> mb-4">
                <h6 class="text-white mb-3"><?php echo e(__('Contact')); ?></h6>
                <ul class="list-unstyled site-footer-contact mb-0">
                    <?php if(!empty($c['footer_address'])): ?><li><i class="fas fa-map-marker-alt me-2"></i><span style="white-space: pre-line"><?php echo e($c['footer_address']); ?></span></li><?php endif; ?>
                    <?php if(!empty($c['footer_phone'])): ?><li><i class="fas fa-phone-alt me-2"></i><a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $c['footer_phone'])); ?>"><?php echo e($c['footer_phone']); ?></a></li><?php endif; ?>
                    <?php if(!empty($c['footer_email'])): ?><li><i class="fas fa-envelope me-2"></i><a href="mailto:<?php echo e($c['footer_email']); ?>"><?php echo e($c['footer_email']); ?></a></li><?php endif; ?>
                    <?php if(!empty($c['footer_hours'])): ?><li><i class="fas fa-clock me-2"></i><?php echo e($c['footer_hours']); ?></li><?php endif; ?>
                    <?php if($wa): ?><li><i class="fab fa-whatsapp me-2"></i><a href="https://wa.me/<?php echo e($wa); ?>" target="_blank" rel="noopener">WhatsApp</a></li><?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="container white-bdrt1 py-3">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
            <p class="copyright-text mb-0 text-white-light ff-heading small text-center text-md-start">
                <?php echo e(!empty($c['copyright']) ? $c['copyright'] : '© ' . date('Y') . ' ' . $site->siteName); ?>

            </p>
            <?php if($legalLinks->isNotEmpty()): ?>
                <ul class="list-inline mb-0 small site-legal-links">
                    <?php $__currentLoopData = $legalLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $url]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-inline-item"><a href="<?php echo e($url); ?>"><?php echo e($label); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</section>


<?php if($wa && ($c['whatsapp_float'] ?? 'deactive') === 'active'): ?>
    <a href="https://wa.me/<?php echo e($wa); ?>" class="site-wa-float" target="_blank" rel="noopener" aria-label="<?php echo e(__('Chat on WhatsApp')); ?>"><i class="fab fa-whatsapp"></i></a>
<?php endif; ?>


<?php if(($c['cookie_banner'] ?? 'deactive') === 'active'): ?>
    <?php
        $cookieDefault = 'We use cookies to keep the site working and to understand how it is used.';
        $cookieText = trim($c['cookie_text'] ?? '');
    ?>
    <div class="site-cookie" role="region" aria-label="<?php echo e(__('Cookie notice')); ?>" data-cookie-notice="<?php echo e($user->code); ?>" hidden>
        <p class="mb-0"><i class="fas fa-cookie-bite me-2"></i><?php echo e($cookieText !== '' && $cookieText !== $cookieDefault ? $cookieText : __($cookieDefault)); ?>

            <?php if($legalLinks->has('privacy_page')): ?>
                <a href="<?php echo e($legalLinks['privacy_page'][1]); ?>"><?php echo e(__('Privacy policy')); ?></a>
            <?php endif; ?>
        </p>
        <button type="button" class="ud-btn btn-thm2 site-cookie-ok"><?php echo e(__('OK')); ?></button>
    </div>
<?php endif; ?>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/footer.blade.php ENDPATH**/ ?>