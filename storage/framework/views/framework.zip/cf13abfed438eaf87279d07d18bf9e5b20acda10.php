<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Parking')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Parking')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $taken = $slots->filter(fn($s) => $s->currentAssignment)->count(); ?>
    <div class="row">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header"><h5 class="mb-0"><?php echo e(__('Add parking slots')); ?></h5></div>
                <div class="card-body">
                    <?php echo e(Form::open(['route' => 'parking.store', 'method' => 'post'])); ?>

                    <div class="form-group"><?php echo e(Form::label('property_id', __('Property'), ['class' => 'form-label'])); ?><?php echo e(Form::select('property_id', $properties, request('property'), ['class' => 'form-control', 'required' => 'required'])); ?></div>
                    <div class="form-group"><?php echo e(Form::label('codes', __('Slot numbers'), ['class' => 'form-label'])); ?><?php echo e(Form::text('codes', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'P1-P20, B1, B2'])); ?>

                        <small class="text-muted"><?php echo e(__('Separate with commas; use a range like P1-P20 to add many.')); ?></small></div>
                    <div class="row">
                        <div class="form-group col-6"><?php echo e(Form::label('vehicle_type', __('Type'), ['class' => 'form-label'])); ?><?php echo e(Form::select('vehicle_type', \App\Models\ParkingSlot::vehicleTypes(), 'car', ['class' => 'form-control'])); ?></div>
                        <div class="form-group col-6"><?php echo e(Form::label('monthly_fee', __('Monthly fee'), ['class' => 'form-label'])); ?><?php echo e(Form::number('monthly_fee', 0, ['class' => 'form-control', 'min' => 0, 'step' => '0.01'])); ?></div>
                    </div>
                    <button type="submit" class="btn btn-secondary w-100"><?php echo e(__('Add Slots')); ?></button>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <h5 class="mb-0"><?php echo e(__('Slots')); ?>: <?php echo e($taken); ?> / <?php echo e($slots->count()); ?> <?php echo e(__('assigned')); ?></h5>
                    <form method="get"><?php echo Form::select('property', ['' => __('All properties')] + $properties->toArray(), request('property'), ['class' => 'form-control form-control-sm', 'onchange' => 'this.form.submit()']); ?></form>
                </div>
                <div class="card-body pt-0">
                    <table class="table mb-0">
                        <thead><tr><th><?php echo e(__('Slot')); ?></th><th><?php echo e(__('Property')); ?></th><th><?php echo e(__('Type')); ?></th><th><?php echo e(__('Fee')); ?></th><th><?php echo e(__('Assigned to')); ?></th><th class="text-end"><?php echo e(__('Action')); ?></th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $a = $slot->currentAssignment; ?>
                                <tr>
                                    <td class="fw-bold"><?php echo e($slot->code); ?></td>
                                    <td><?php echo e(optional($slot->properties)->name); ?></td>
                                    <td><?php echo e(\App\Models\ParkingSlot::vehicleTypes()[$slot->vehicle_type] ?? $slot->vehicle_type); ?></td>
                                    <td><?php echo e($slot->monthly_fee > 0 ? priceFormat($slot->monthly_fee) : '-'); ?></td>
                                    <td>
                                        <?php if($a): ?>
                                            <span class="badge bg-light-success"><?php echo e(optional(optional($a->tenants)->user)->name); ?></span>
                                            <small class="text-muted"><?php echo e($a->vehicle_number); ?> <?php echo e($a->vehicle_model); ?></small>
                                        <?php else: ?>
                                            <?php echo e(Form::open(['route' => ['parking.assign', $slot->id], 'method' => 'post', 'class' => 'd-flex gap-1'])); ?>

                                            <?php echo e(Form::select('tenant_id', $tenants, null, ['class' => 'form-control form-control-sm', 'placeholder' => __('Tenant'), 'required' => 'required'])); ?>

                                            <input type="text" name="vehicle_number" class="form-control form-control-sm" placeholder="<?php echo e(__('Vehicle no.')); ?>" style="max-width:110px">
                                            <button class="btn btn-sm btn-light-secondary"><?php echo e(__('Assign')); ?></button>
                                            <?php echo e(Form::close()); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($a): ?>
                                            <?php echo e(Form::open(['route' => ['parking.release', $slot->id], 'method' => 'post', 'class' => 'd-inline'])); ?>

                                            <button class="btn btn-sm btn-light-warning"><?php echo e(__('Free')); ?></button>
                                            <?php echo e(Form::close()); ?>

                                        <?php else: ?>
                                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['parking.destroy', $slot->id], 'class' => 'd-inline']); ?>

                                            <a class="avtar avtar-xs btn-link-danger text-danger confirm_dialog" href="#"><i data-feather="trash-2"></i></a>
                                            <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="6" class="text-muted"><?php echo e(__('No parking slots yet.')); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/parking/index.blade.php ENDPATH**/ ?>