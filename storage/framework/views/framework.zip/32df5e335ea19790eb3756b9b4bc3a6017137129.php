<?php
    $searchOptions = ($c['show_search'] ?? 'active') === 'active' ? \App\Support\PropertySearch::options($user->id) : null;
    if ($searchOptions && !$searchOptions['listings'] && !count($searchOptions['cities'])) {
        $searchOptions = null; // nothing listed yet
    }
?>
<section class="hero-home11 site-hero" id="<?php echo e($sectionId); ?>">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="<?php echo e(!empty($c['banner_image1_path']) ? 'col-lg-6' : 'col-lg-9'); ?> mb30-md">
                <div class="home11-hero-content">
                    <h1 class="title animate-up-2"><?php echo e($c['title'] ?? ''); ?></h1>
                    <?php if(!empty($c['sub_title'])): ?>
                        <p class="text animate-up-3 h4 text-muted mt-3"><?php echo e($c['sub_title']); ?></p>
                    <?php endif; ?>
                    <?php if(!empty($c['button_text'])): ?>
                        <a href="<?php echo e($c['button_link'] ?: route('property.home', ['code' => $user->code])); ?>" class="ud-btn btn-thm2 mt-4"><?php echo e($c['button_text']); ?> <i class="fal fa-arrow-right-long"></i></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(!empty($c['banner_image1_path'])): ?>
                <div class="col-lg-6">
                    <div class="home11-hero-img text-center text-xxl-end">
                        <img class="bdrs20 ban-img" src="<?php echo e(\App\Support\WebsiteImage::url($c['banner_image1_path'], 1200)); ?>" alt="<?php echo e($c['title'] ?? ''); ?>">
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php if($searchOptions): ?>
            <div class="site-search-card site-hero-search">
                <?php echo $__env->make('theme._search_form', ['compact' => true, 'options' => $searchOptions, 'f' => []], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /home/etheonbe/public_html/resources/views/theme/sections/banner.blade.php ENDPATH**/ ?>