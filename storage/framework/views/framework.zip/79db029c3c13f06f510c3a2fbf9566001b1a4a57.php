<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Polls')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e(__('Polls')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card table-card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><?php echo e(__('Polls')); ?></h5>
            <a href="#" class="btn btn-secondary customModal" data-size="lg" data-url="<?php echo e(route('poll.create')); ?>" data-title="<?php echo e(__('New Poll')); ?>"><i class="ti ti-circle-plus align-text-bottom"></i> <?php echo e(__('New Poll')); ?></a>
        </div>
        <div class="card-body pt-0">
            <table class="table table-hover">
                <thead><tr><th><?php echo e(__('Question')); ?></th><th><?php echo e(__('Audience')); ?></th><th><?php echo e(__('Votes')); ?></th><th><?php echo e(__('Closes')); ?></th><th><?php echo e(__('Status')); ?></th><th class="text-end"><?php echo e(__('Action')); ?></th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('poll.show', $poll->id)); ?>" class="fw-semibold"><?php echo e($poll->question); ?></a></td>
                            <td><?php echo e(optional($poll->properties)->name ?? __('All properties')); ?></td>
                            <td><?php echo e($poll->votes()->count()); ?></td>
                            <td><?php echo e($poll->closes_on ? dateFormat($poll->closes_on) : '-'); ?></td>
                            <td><span class="badge bg-light-<?php echo e($poll->isOpen() ? 'success' : 'secondary'); ?>"><?php echo e($poll->isOpen() ? __('Open') : __('Closed')); ?></span></td>
                            <td class="text-end">
                                <div class="cart-action">
                                    <?php echo e(Form::open(['route' => ['poll.close', $poll->id], 'method' => 'post', 'class' => 'd-inline'])); ?>

                                    <button class="btn btn-sm btn-light-secondary"><?php echo e($poll->is_active ? __('Close') : __('Reopen')); ?></button>
                                    <?php echo e(Form::close()); ?>

                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['poll.destroy', $poll->id], 'class' => 'd-inline']); ?>

                                    <a class="avtar avtar-xs btn-link-danger text-danger confirm_dialog" href="#"><i data-feather="trash-2"></i></a>
                                    <?php echo Form::close(); ?>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="text-center text-muted"><?php echo e(__('No polls yet. Ask tenants for a quick decision, like "Which day for the society meeting?".')); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/etheonbe/public_html/resources/views/poll/index.blade.php ENDPATH**/ ?>